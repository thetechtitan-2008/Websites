import React, { useState, useEffect } from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import IntroAnimation from './components/IntroAnimation';
import Header from './components/Header';
import Hero from './components/Hero';
import WhySayNo from './components/WhySayNo';
import Stories from './components/Stories';
import Interactive from './components/Interactive';
import Pledge from './components/Pledge';
import Resources from './components/Resources';
import Footer from './components/Footer';

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [showIntro, setShowIntro] = useState(true);
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'why-say-no', 'stories', 'interactive', 'pledge', 'resources'];
      const scrollPosition = window.scrollY + 200;

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = document.getElementById(sections[i]);
        if (section && section.offsetTop <= scrollPosition) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleIntroComplete = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setShowIntro(false);
      setIsTransitioning(false);
    }, 800);
  };

  if (showIntro) {
    return (
      <ThemeProvider>
        <div className={`transition-opacity duration-800 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
          <IntroAnimation onComplete={handleIntroComplete} />
        </div>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider>
      <div className={`min-h-screen bg-white dark:bg-gray-900 transition-all duration-800 ${isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
        <Header activeSection={activeSection} onSectionChange={setActiveSection} />
        <main>
          <Hero />
          <WhySayNo />
          <Stories />
          <Interactive />
          <Pledge />
          <Resources />
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  );
}

export default App;