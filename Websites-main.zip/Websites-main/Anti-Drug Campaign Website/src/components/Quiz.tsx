import React, { useState, useEffect } from 'react';
import { Brain, Trophy, Star, CheckCircle, X, ArrowRight, RotateCcw, Sparkles, XCircle } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  category: string;
}

interface QuizProps {
  onClose?: () => void;
}

const Quiz: React.FC<QuizProps> = ({ onClose }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(30);
  const [quizStarted, setQuizStarted] = useState(false);

  const questions: Question[] = [
    {
      id: 1,
      question: "What is the most important reason to avoid drugs during your teenage years?",
      options: [
        "To save money for other things",
        "Your brain is still developing until age 25",
        "To avoid getting in trouble with parents",
        "Because they taste bad"
      ],
      correctAnswer: 1,
      explanation: "Your brain continues developing until age 25. Drugs can permanently damage this development, affecting memory, learning, and decision-making abilities.",
      category: "Health & Development"
    },
    {
      id: 2,
      question: "If a friend offers you drugs at a party, what's the best response?",
      options: [
        "Take them to avoid looking uncool",
        "Say 'No thanks, I'm good' and suggest doing something else fun",
        "Make an excuse and leave immediately",
        "Tell them they're stupid for using drugs"
      ],
      correctAnswer: 1,
      explanation: "A confident, friendly 'no' while suggesting an alternative activity shows maturity and can help redirect the situation positively.",
      category: "Social Skills"
    },
    {
      id: 3,
      question: "Which of these is a healthy way to deal with stress instead of using drugs?",
      options: [
        "Isolating yourself from everyone",
        "Exercise, talking to friends, or practicing hobbies",
        "Eating lots of junk food",
        "Staying awake all night"
      ],
      correctAnswer: 1,
      explanation: "Physical activity, social support, and engaging in hobbies are proven healthy ways to manage stress and boost mood naturally.",
      category: "Coping Strategies"
    },
    {
      id: 4,
      question: "What should you do if you suspect a friend is using drugs?",
      options: [
        "Ignore it - it's none of your business",
        "Talk to them privately and encourage them to get help",
        "Tell everyone at school about it",
        "Start avoiding them completely"
      ],
      correctAnswer: 1,
      explanation: "True friendship means caring enough to have difficult conversations. Approach them with compassion and encourage professional help.",
      category: "Friendship & Support"
    },
    {
      id: 5,
      question: "Which statement about drug addiction is TRUE?",
      options: [
        "Only weak people become addicted",
        "You can't get addicted from trying drugs just once",
        "Addiction is a medical condition that can happen to anyone",
        "Smart people never become addicted"
      ],
      correctAnswer: 2,
      explanation: "Addiction is a complex medical condition that can affect anyone, regardless of intelligence, strength, or background. It changes brain chemistry.",
      category: "Understanding Addiction"
    },
    {
      id: 6,
      question: "What's the best way to build confidence without using substances?",
      options: [
        "Comparing yourself to others constantly",
        "Developing skills, helping others, and celebrating small wins",
        "Avoiding all challenging situations",
        "Pretending to be someone you're not"
      ],
      correctAnswer: 1,
      explanation: "Real confidence comes from personal growth, contributing to others, and recognizing your achievements - no matter how small.",
      category: "Self-Confidence"
    },
    {
      id: 7,
      question: "If you're at a party where drugs are present, what's the smartest action?",
      options: [
        "Stay but avoid the drug area",
        "Leave the party and find safer activities",
        "Try to stop everyone from using drugs",
        "Hide in the bathroom until it's over"
      ],
      correctAnswer: 1,
      explanation: "The safest choice is to leave situations where illegal activities are happening. Your safety and reputation are more important than any party.",
      category: "Decision Making"
    },
    {
      id: 8,
      question: "What's a good response when someone says 'Everyone's doing it' about drug use?",
      options: [
        "'If everyone jumped off a bridge, would you?'",
        "'That's not true, and I choose what's right for me'",
        "Just walk away without saying anything",
        "'Maybe I should try it then'"
      ],
      correctAnswer: 1,
      explanation: "This response is assertive but not confrontational. It challenges the false claim while affirming your right to make your own choices.",
      category: "Peer Pressure"
    },
    {
      id: 9,
      question: "Which activity is MOST likely to give you a natural 'high' feeling?",
      options: [
        "Sitting alone in your room",
        "Exercising, playing music, or achieving a goal",
        "Watching TV for hours",
        "Complaining about problems"
      ],
      correctAnswer: 1,
      explanation: "Physical activity, creative expression, and accomplishments naturally release endorphins - your body's 'feel-good' chemicals.",
      category: "Natural Highs"
    },
    {
      id: 10,
      question: "What's the most important thing to remember about your future?",
      options: [
        "It's already decided by your circumstances",
        "You have the power to shape it with your choices today",
        "It doesn't matter what you do now",
        "Only lucky people have good futures"
      ],
      correctAnswer: 1,
      explanation: "Every choice you make today - including saying no to drugs - is building the foundation for your future success and happiness.",
      category: "Future Planning"
    }
  ];

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (quizStarted && !showResult && !quizCompleted && timeLeft > 0) {
      timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
    } else if (timeLeft === 0 && !showResult) {
      handleNextQuestion();
    }
    return () => clearTimeout(timer);
  }, [timeLeft, quizStarted, showResult, quizCompleted]);

  const startQuiz = () => {
    setQuizStarted(true);
    setTimeLeft(30);
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    const isCorrect = selectedAnswer === questions[currentQuestion].correctAnswer;
    if (isCorrect) {
      setScore(score + 1);
    }
    
    setUserAnswers([...userAnswers, selectedAnswer || -1]);
    setShowResult(true);
    
    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setShowResult(false);
        setTimeLeft(30);
      } else {
        setQuizCompleted(true);
      }
    }, 2500);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setScore(0);
    setShowResult(false);
    setQuizCompleted(false);
    setUserAnswers([]);
    setTimeLeft(30);
    setQuizStarted(false);
  };

  const getScoreMessage = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage >= 90) return { message: "Outstanding! You're a Drug-Free Champion! 🏆", color: "from-yellow-400 to-orange-500" };
    if (percentage >= 80) return { message: "Excellent! You really know your stuff! ⭐", color: "from-green-400 to-blue-500" };
    if (percentage >= 70) return { message: "Great job! You're on the right track! 👍", color: "from-blue-400 to-purple-500" };
    if (percentage >= 60) return { message: "Good effort! Keep learning and growing! 📚", color: "from-purple-400 to-pink-500" };
    return { message: "Keep learning! Every step counts! 💪", color: "from-pink-400 to-red-500" };
  };

  if (!quizStarted) {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center p-4 z-50 overflow-auto">
        {/* Close Button */}
        {onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-60 bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full p-2 transition-all duration-200 hover:scale-110"
          >
            <XCircle className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
          </button>
        )}
        
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl sm:rounded-3xl p-6 sm:p-8 md:p-12 shadow-2xl border border-white/20">
            <div className="relative mb-6 sm:mb-8">
              <Brain className="w-16 h-16 sm:w-20 sm:h-20 mx-auto text-yellow-400 animate-pulse" />
              <Sparkles className="absolute -top-1 -right-1 sm:-top-2 sm:-right-2 w-6 h-6 sm:w-8 sm:h-8 text-pink-400 animate-bounce" />
              <Sparkles className="absolute -bottom-1 -left-1 sm:-bottom-2 sm:-left-2 w-4 h-4 sm:w-6 sm:h-6 text-blue-400 animate-pulse" />
            </div>
            
            <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-yellow-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              Drug-Free Quiz Challenge
            </h1>
            
            <p className="text-lg sm:text-xl md:text-2xl text-white/90 mb-6 sm:mb-8 leading-relaxed">
              Test your knowledge and become a <span className="font-bold text-yellow-400">Drug-Free Champion!</span>
            </p>
            
            <div className="grid grid-cols-3 gap-3 sm:gap-4 mb-6 sm:mb-8 text-white/80">
              <div className="bg-white/10 rounded-xl sm:rounded-2xl p-3 sm:p-4">
                <div className="text-xl sm:text-2xl font-bold text-yellow-400">10</div>
                <div className="text-xs sm:text-sm">Questions</div>
              </div>
              <div className="bg-white/10 rounded-xl sm:rounded-2xl p-3 sm:p-4">
                <div className="text-xl sm:text-2xl font-bold text-green-400">30s</div>
                <div className="text-xs sm:text-sm">Per Question</div>
              </div>
              <div className="bg-white/10 rounded-xl sm:rounded-2xl p-3 sm:p-4">
                <div className="text-xl sm:text-2xl font-bold text-blue-400">5min</div>
                <div className="text-xs sm:text-sm">Total Time</div>
              </div>
            </div>
            
            <button
              onClick={startQuiz}
              className="group bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-lg sm:text-xl hover:scale-110 transition-all duration-300 shadow-2xl hover:shadow-yellow-500/25 flex items-center gap-2 sm:gap-3 mx-auto"
            >
              Start Quiz Challenge
              <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (quizCompleted) {
    const scoreMessage = getScoreMessage();
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center p-4 z-50 overflow-auto">
        {/* Close Button */}
        {onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-60 bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full p-2 transition-all duration-200 hover:scale-110"
          >
            <XCircle className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
          </button>
        )}
        
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl sm:rounded-3xl p-6 sm:p-8 md:p-12 shadow-2xl border border-white/20">
            <div className="mb-6 sm:mb-8">
              <div className="relative inline-block">
                <Trophy className="w-16 h-16 sm:w-20 sm:h-20 mx-auto text-yellow-400 animate-bounce" />
                <div className="absolute inset-0 w-16 h-16 sm:w-20 sm:h-20 mx-auto bg-yellow-400/20 rounded-full animate-ping"></div>
              </div>
            </div>
            
            <h2 className="text-3xl sm:text-4xl md:text-6xl font-bold mb-4 sm:mb-6 text-white">
              Quiz Complete!
            </h2>
            
            <div className={`bg-gradient-to-r ${scoreMessage.color} rounded-xl sm:rounded-2xl p-4 sm:p-6 mb-6 sm:mb-8`}>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-2">
                {score}/{questions.length}
              </div>
              <div className="text-lg sm:text-xl text-white/90">
                {scoreMessage.message}
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-6 sm:mb-8">
              <div className="bg-white/10 rounded-xl sm:rounded-2xl p-4 sm:p-6">
                <h3 className="text-lg sm:text-xl font-bold text-white mb-3 sm:mb-4">Your Performance</h3>
                <div className="space-y-2">
                  <div className="flex justify-between text-white/80 text-sm sm:text-base">
                    <span>Correct Answers:</span>
                    <span className="text-green-400 font-bold">{score}</span>
                  </div>
                  <div className="flex justify-between text-white/80 text-sm sm:text-base">
                    <span>Accuracy:</span>
                    <span className="text-blue-400 font-bold">{Math.round((score / questions.length) * 100)}%</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 rounded-xl sm:rounded-2xl p-4 sm:p-6">
                <h3 className="text-lg sm:text-xl font-bold text-white mb-3 sm:mb-4">Categories Mastered</h3>
                <div className="flex flex-wrap gap-1 sm:gap-2">
                  {Array.from(new Set(questions.map(q => q.category))).slice(0, 3).map((category, index) => (
                    <span key={index} className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm">
                      {category.split(' ')[0]}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="flex flex-col gap-3 sm:gap-4 justify-center">
              <button
                onClick={resetQuiz}
                className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-base sm:text-lg hover:scale-105 transition-all duration-200 shadow-xl flex items-center gap-2 justify-center"
              >
                <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
                Take Quiz Again
              </button>
              
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
                <button
                  onClick={() => {
                    if (onClose) onClose();
                    const element = document.getElementById('pledge');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="bg-gradient-to-r from-green-500 to-teal-500 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-base sm:text-lg hover:scale-105 transition-all duration-200 shadow-xl flex items-center gap-2 justify-center"
                >
                  <Star className="w-4 h-4 sm:w-5 sm:h-5" />
                  Take the Pledge
                </button>
                
                {onClose && (
                  <button
                    onClick={onClose}
                    className="bg-gradient-to-r from-gray-500 to-gray-600 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-base sm:text-lg hover:scale-105 transition-all duration-200 shadow-xl flex items-center gap-2 justify-center"
                  >
                    <XCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                    Back to Website
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center p-4 z-50 overflow-auto">
      {/* Close Button */}
      {onClose && (
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-60 bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full p-2 transition-all duration-200 hover:scale-110"
        >
          <XCircle className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
        </button>
      )}
      
      <div className="max-w-4xl mx-auto w-full">
        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-white/80 font-semibold text-sm sm:text-base">
              Question {currentQuestion + 1} of {questions.length}
            </span>
            <div className="flex items-center gap-2 text-white/80">
              <div className={`w-2 h-2 sm:w-3 sm:h-3 rounded-full ${timeLeft <= 10 ? 'bg-red-400 animate-pulse' : 'bg-green-400'}`}></div>
              <span className={`font-bold text-sm sm:text-base ${timeLeft <= 10 ? 'text-red-400' : 'text-green-400'}`}>
                {timeLeft}s
              </span>
            </div>
          </div>
          <div className="w-full bg-white/20 rounded-full h-2 sm:h-3">
            <div 
              className="bg-gradient-to-r from-yellow-400 to-orange-500 h-2 sm:h-3 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-2xl sm:rounded-3xl p-6 sm:p-8 md:p-12 shadow-2xl border border-white/20">
          {!showResult ? (
            <>
              <div className="mb-6">
                <div className="inline-block bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-semibold mb-4">
                  {currentQ.category}
                </div>
                <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6 leading-relaxed">
                  {currentQ.question}
                </h2>
              </div>

              <div className="grid gap-2 sm:gap-3 mb-6">
                {currentQ.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl text-left transition-all duration-200 hover:scale-105 ${
                      selectedAnswer === index
                        ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-xl'
                        : 'bg-white/10 text-white/90 hover:bg-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-3 sm:gap-4">
                      <div className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-bold text-sm sm:text-base ${
                        selectedAnswer === index ? 'bg-white text-blue-600' : 'bg-white/20 text-white'
                      }`}>
                        {String.fromCharCode(65 + index)}
                      </div>
                      <span className="text-sm sm:text-base md:text-lg">{option}</span>
                    </div>
                  </button>
                ))}
              </div>

              <button
                onClick={handleNextQuestion}
                disabled={selectedAnswer === null}
                className={`w-full py-3 sm:py-4 rounded-xl sm:rounded-2xl font-bold text-base sm:text-lg transition-all duration-200 ${
                  selectedAnswer !== null
                    ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white hover:scale-105 shadow-xl'
                    : 'bg-gray-500 text-gray-300 cursor-not-allowed'
                }`}
              >
                {currentQuestion === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
                <ArrowRight className="inline-block ml-2 w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            </>
          ) : (
            <div className="text-center">
              <div className="mb-6">
                {selectedAnswer === currentQ.correctAnswer ? (
                  <CheckCircle className="w-12 h-12 sm:w-16 sm:h-16 text-green-400 mx-auto mb-4 animate-bounce" />
                ) : (
                  <X className="w-12 h-12 sm:w-16 sm:h-16 text-red-400 mx-auto mb-4 animate-pulse" />
                )}
                
                <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4">
                  {selectedAnswer === currentQ.correctAnswer ? 'Correct!' : 'Not quite right!'}
                </h3>
                
                <div className="bg-white/10 rounded-xl sm:rounded-2xl p-4 text-left">
                  <h4 className="font-bold text-white mb-2 text-sm sm:text-base">Explanation:</h4>
                  <p className="text-xs sm:text-sm md:text-base text-white/90 leading-relaxed">{currentQ.explanation}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Quiz;