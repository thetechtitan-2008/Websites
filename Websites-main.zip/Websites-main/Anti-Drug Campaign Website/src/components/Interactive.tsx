import React, { useState } from 'react';
import { Gamepad2, Trophy, Star, Sparkles, ArrowRight } from 'lucide-react';
import Quiz from './Quiz';
import ScrollAnimation from './ScrollAnimation';

const Interactive: React.FC = () => {
  const [showQuiz, setShowQuiz] = useState(false);

  if (showQuiz) {
    return <Quiz onClose={() => setShowQuiz(false)} />;
  }

  return (
    <section id="interactive" className="py-12 sm:py-20 bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4">
        <ScrollAnimation direction="fade" className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
            Fun Zone
          </h2>
          <p className="text-lg sm:text-xl text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            Test your knowledge and have fun while learning about making smart, healthy choices!
          </p>
        </ScrollAnimation>

        <ScrollAnimation direction="up" delay={300} className="max-w-4xl mx-auto">
          {/* Quiz Challenge Card */}
          <div className="relative overflow-hidden bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-600 rounded-2xl sm:rounded-3xl shadow-2xl">
            {/* Animated Background Elements */}
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute -top-10 -left-10 w-32 h-32 sm:w-40 sm:h-40 bg-white/10 rounded-full animate-pulse"></div>
              <div className="absolute top-20 -right-10 w-24 h-24 sm:w-32 sm:h-32 bg-yellow-400/20 rounded-full animate-bounce"></div>
              <div className="absolute -bottom-10 left-20 w-28 h-28 sm:w-36 sm:h-36 bg-pink-400/15 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
              <Sparkles className="absolute top-6 right-6 sm:top-10 sm:right-20 w-6 h-6 sm:w-8 sm:h-8 text-yellow-300 animate-spin" style={{ animationDuration: '3s' }} />
              <Star className="absolute bottom-16 right-6 sm:bottom-20 sm:right-10 w-4 h-4 sm:w-6 sm:h-6 text-pink-300 animate-bounce" style={{ animationDelay: '2s' }} />
            </div>

            <div className="relative z-10 p-6 sm:p-8 md:p-12 text-center text-white">
              <div className="mb-6 sm:mb-8">
                <div className="relative inline-block">
                  <Trophy className="w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-4 text-yellow-400 animate-bounce" />
                  <div className="absolute inset-0 bg-yellow-400/20 rounded-full animate-ping"></div>
                </div>
                
                <h3 className="text-2xl sm:text-3xl md:text-5xl font-bold mb-3 sm:mb-4 bg-gradient-to-r from-yellow-300 to-pink-300 bg-clip-text text-transparent">
                  Drug-Free Quiz Challenge
                </h3>
                
                <p className="text-lg sm:text-xl md:text-2xl mb-4 sm:mb-6 opacity-90">
                  Test your knowledge and become a <span className="font-bold text-yellow-300">Champion!</span>
                </p>
              </div>

              {/* Quiz Features */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-6 hover:bg-white/20 transition-all duration-300 hover:scale-105">
                  <Gamepad2 className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-2 sm:mb-3 text-green-400" />
                  <h4 className="text-sm sm:text-lg font-bold mb-1 sm:mb-2">Interactive Fun</h4>
                  <p className="text-xs sm:text-sm opacity-80">Engaging questions with instant feedback</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-6 hover:bg-white/20 transition-all duration-300 hover:scale-105">
                  <Star className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-2 sm:mb-3 text-yellow-400" />
                  <h4 className="text-sm sm:text-lg font-bold mb-1 sm:mb-2">Learn & Grow</h4>
                  <p className="text-xs sm:text-sm opacity-80">Educational content that matters</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-6 hover:bg-white/20 transition-all duration-300 hover:scale-105">
                  <Trophy className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-2 sm:mb-3 text-purple-400" />
                  <h4 className="text-sm sm:text-lg font-bold mb-1 sm:mb-2">Earn Recognition</h4>
                  <p className="text-xs sm:text-sm opacity-80">Get your score and celebrate success</p>
                </div>
              </div>

              {/* Quiz Stats */}
              <div className="flex justify-center gap-4 sm:gap-8 mb-6 sm:mb-8 text-center">
                <div>
                  <div className="text-2xl sm:text-3xl font-bold text-yellow-300">10</div>
                  <div className="text-xs sm:text-sm opacity-80">Questions</div>
                </div>
                <div>
                  <div className="text-2xl sm:text-3xl font-bold text-green-300">30s</div>
                  <div className="text-xs sm:text-sm opacity-80">Per Question</div>
                </div>
                <div>
                  <div className="text-2xl sm:text-3xl font-bold text-blue-300">5min</div>
                  <div className="text-xs sm:text-sm opacity-80">Total Time</div>
                </div>
              </div>

              {/* Start Quiz Button */}
              <button
                onClick={() => setShowQuiz(true)}
                className="group relative bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 text-white px-8 sm:px-12 py-4 sm:py-6 rounded-full font-bold text-lg sm:text-xl hover:scale-110 transition-all duration-300 shadow-2xl hover:shadow-yellow-500/25 overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-yellow-300 via-orange-400 to-red-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="relative flex items-center gap-2 sm:gap-3">
                  <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 group-hover:animate-spin" />
                  Start Quiz Challenge
                  <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 group-hover:translate-x-2 transition-transform duration-300" />
                </div>
              </button>

              <p className="text-xs sm:text-sm opacity-70 mt-3 sm:mt-4">
                Ready to test your drug-free knowledge? Let's go! 🚀
              </p>
            </div>
          </div>
        </ScrollAnimation>

        {/* Additional Fun Elements */}
        <ScrollAnimation direction="up" delay={600}>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mt-8 sm:mt-12">
            <div className="bg-white dark:bg-gray-800 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
              <div className="flex items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
                  <Star className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-800 dark:text-white">Challenge Yourself</h3>
              </div>
              <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300">
                Each question is designed to help you think critically about important life choices. No pressure - just learning and fun!
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
              <div className="flex items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <Trophy className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-800 dark:text-white">Celebrate Success</h3>
              </div>
              <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300">
                Every correct answer brings you closer to becoming a Drug-Free Champion. Share your results with friends!
              </p>
            </div>
          </div>
        </ScrollAnimation>
      </div>
    </section>
  );
};

export default Interactive;