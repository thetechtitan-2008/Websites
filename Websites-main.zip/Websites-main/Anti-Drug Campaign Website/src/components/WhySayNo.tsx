import React, { useState } from 'react';
import { Brain, Heart, DollarSign, GraduationCap, AlertTriangle, ChevronDown } from 'lucide-react';
import ScrollAnimation from './ScrollAnimation';

const WhySayNo: React.FC = () => {
  const [expandedCard, setExpandedCard] = useState<number | null>(null);

  const reasons = [
    {
      icon: Brain,
      title: 'Protect Your Brain',
      color: 'from-purple-500 to-pink-500',
      bgColor: 'bg-purple-50',
      shortDesc: 'Your brain is still growing until age 25!',
      fullDesc: 'Drugs can damage your developing brain, affecting memory, learning, and decision-making. Keep your brain healthy and sharp for all the amazing things you\'ll accomplish!',
    },
    {
      icon: Heart,
      title: 'Keep Your Family Close',
      color: 'from-red-500 to-pink-500',
      bgColor: 'bg-red-50',
      shortDesc: 'Your family loves and supports you.',
      fullDesc: 'Drug use can hurt relationships with the people who care about you most. Your family wants to see you succeed and be happy. Keep their trust and love strong.',
    },
    {
      icon: DollarSign,
      title: 'Save Your Money',
      color: 'from-green-500 to-blue-500',
      bgColor: 'bg-green-50',
      shortDesc: 'Drugs are expensive and wasteful.',
      fullDesc: 'Instead of wasting money on harmful substances, you could save for things you really want - games, clothes, trips, or your future education. Make smart financial choices!',
    },
    {
      icon: GraduationCap,
      title: 'Excel in School',
      color: 'from-blue-500 to-purple-500',
      bgColor: 'bg-blue-50',
      shortDesc: 'Stay focused on your dreams and goals.',
      fullDesc: 'Drugs can make it hard to concentrate, remember things, and do well in school. Your education is your superpower - don\'t let anything take that away from you!',
    },
    {
      icon: AlertTriangle,
      title: 'Stay Safe',
      color: 'from-orange-500 to-red-500',
      bgColor: 'bg-orange-50',
      shortDesc: 'Drugs can be dangerous and unpredictable.',
      fullDesc: 'You never know what\'s really in illegal drugs or how your body will react. Why risk your health and safety? You have so much to live for and achieve!',
    },
  ];

  const toggleCard = (index: number) => {
    setExpandedCard(expandedCard === index ? null : index);
  };

  return (
    <section id="why-say-no" className="py-12 sm:py-20 bg-gradient-to-br from-blue-50 to-green-50 dark:from-gray-800 dark:to-gray-700">
      <div className="container mx-auto px-4">
        <ScrollAnimation direction="fade" className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-blue-600 to-green-600 dark:from-blue-400 dark:to-green-400 bg-clip-text text-transparent">
            Why Say No to Drugs?
          </h2>
          <p className="text-lg sm:text-xl text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            Here are the top reasons to keep your life drug-free and amazing! Tap on each card to learn more.
          </p>
        </ScrollAnimation>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 max-w-6xl mx-auto">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            const isExpanded = expandedCard === index;
            
            return (
              <ScrollAnimation 
                key={index}
                direction="up"
                delay={index * 150}
              >
                <div
                  className={`${reason.bgColor} dark:bg-gray-800 rounded-2xl p-4 sm:p-6 cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-105 ${
                    isExpanded ? 'shadow-2xl scale-105' : 'shadow-lg'
                  }`}
                  onClick={() => toggleCard(index)}
                >
                  <div className="flex items-center justify-between mb-3 sm:mb-4">
                    <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gradient-to-r ${reason.color} flex items-center justify-center`}>
                      <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                    <div className={`transform transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`}>
                      <ChevronDown className="w-5 h-5 sm:w-6 sm:h-6 text-gray-600" />
                    </div>
                  </div>
                  
                  <h3 className="text-lg sm:text-xl font-bold mb-2 text-gray-800 dark:text-white">{reason.title}</h3>
                  <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300 mb-3 sm:mb-4">{reason.shortDesc}</p>
                  
                  <div className={`overflow-hidden transition-all duration-500 ${
                    isExpanded ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                  }`}>
                    <div className="border-t border-gray-200 dark:border-gray-600 pt-3 sm:pt-4">
                      <p className="text-sm sm:text-base text-gray-700 dark:text-gray-300 leading-relaxed">{reason.fullDesc}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-center mt-3 sm:mt-4">
                    <span className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
                      {isExpanded ? 'Tap to collapse' : 'Tap to expand'}
                    </span>
                  </div>
                </div>
              </ScrollAnimation>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default WhySayNo;