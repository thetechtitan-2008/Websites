import React from 'react';
import { Phone, MessageSquare, Download, ExternalLink, Heart, Shield, Users, BookOpen } from 'lucide-react';
import ScrollAnimation from './ScrollAnimation';

const Resources: React.FC = () => {
  const emergencyContacts = [
    {
      name: 'National Suicide Prevention Lifeline',
      phone: '112',
      description: 'Free, confidential support 24/7',
      icon: Heart,
    },
    {
      name: 'Crisis Text Line',
      phone: 'Text HOME to 741741',
      description: 'Crisis counseling via text message',
      icon: MessageSquare,
    },
    {
      name: 'SAMHSA National Helpline',
      phone: '1-800-662-4357',
      description: 'Treatment referral service',
      icon: Shield,
    },
    {
      name: 'School Counselor',
      phone: 'Contact your school office',
      description: 'Your counselor is here to help',
      icon: Users,
    },
  ];

  const resources = [
    {
      title: 'Narcotics Control Bureau (NCB)',
      description: 'Report drug-related activities to help keep your community safe',
      type: 'Hotline: 1800-11-0031',
      icon: Shield,
      phone: '1800-11-0031',
    },
    {
      title: 'Local Police Station',
      description: 'Contact your nearest police station for immediate help',
      type: 'Emergency: 112',
      icon: Phone,
      phone: '112',
    },
    {
      title: 'Anonymous Drug Tip Line',
      description: 'Report anonymously without revealing your identity',
      type: 'Tip Line: 1800-11-0032',
      icon: MessageSquare,
      phone: '1800-11-0032',
    },
    {
      title: 'School Anti-Drug Committee',
      description: 'Report to your school counselor or principal',
      type: 'Contact School Office',
      icon: BookOpen,
    },
  ];

  return (
    <section id="resources" className="py-12 sm:py-20 bg-gradient-to-br from-teal-50 to-blue-50 dark:from-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-4">
        <ScrollAnimation direction="fade" className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-teal-600 to-blue-600 dark:from-teal-400 dark:to-blue-400 bg-clip-text text-transparent">
            Resources & Help
          </h2>
          <p className="text-lg sm:text-xl text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            You're not alone in this journey. Here are resources to help you stay strong and get support when you need it.
          </p>
        </ScrollAnimation>

        <div className="max-w-6xl mx-auto">
          {/* Emergency Contacts */}
          <ScrollAnimation direction="up" delay={200} className="mb-12 sm:mb-16">
            <h3 className="text-2xl sm:text-3xl font-bold text-center mb-6 sm:mb-8 text-gray-800 dark:text-white">
              Need Help? Contact These Resources
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
              {emergencyContacts.map((contact, index) => {
                const Icon = contact.icon;
                return (
                  <ScrollAnimation key={index} direction="left" delay={index * 100}>
                    <div className="bg-white dark:bg-gray-800 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105">
                      <div className="flex items-start gap-3 sm:gap-4">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-teal-500 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg sm:text-xl font-bold mb-2 text-gray-800 dark:text-white">{contact.name}</h4>
                          <p className="text-lg sm:text-2xl font-bold text-teal-600 mb-2">{contact.phone}</p>
                          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300">{contact.description}</p>
                        </div>
                      </div>
                    </div>
                  </ScrollAnimation>
                );
              })}
            </div>
          </ScrollAnimation>

          {/* Additional Resources */}
          <ScrollAnimation direction="up" delay={400}>
            <h3 className="text-2xl sm:text-3xl font-bold text-center mb-8 sm:mb-12 text-gray-800 dark:text-white">
              How to Report Drug Activities
            </h3>
            
            <ScrollAnimation direction="scale" delay={600}>
              <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-xl sm:rounded-2xl p-6 mb-6 sm:mb-8 text-white text-center">
                <Shield className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4" />
                <h4 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3">Be a Hero in Your Community!</h4>
                <p className="text-base sm:text-lg opacity-90 mb-3 sm:mb-4">
                  If you see someone using or selling drugs, you can help protect your friends and community by reporting it safely.
                </p>
                <p className="text-sm sm:text-base opacity-80">
                  Remember: Reporting drug activities helps save lives and keeps everyone safe. You're being brave and responsible!
                </p>
              </div>
            </ScrollAnimation>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
              {resources.map((resource, index) => {
                const Icon = resource.icon;
                return (
                  <ScrollAnimation key={index} direction="right" delay={index * 150}>
                    <div className="bg-white dark:bg-gray-800 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105">
                      <div className="flex items-start gap-3 sm:gap-4">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg sm:text-xl font-bold mb-2 text-gray-800 dark:text-white">{resource.title}</h4>
                          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300 mb-2 sm:mb-3">{resource.description}</p>
                          <span className="inline-flex items-center gap-2 text-blue-600 dark:text-blue-400 font-semibold text-sm sm:text-base">
                            {resource.type}
                            {resource.phone && <Phone className="w-3 h-3 sm:w-4 sm:h-4" />}
                          </span>
                        </div>
                      </div>
                    </div>
                  </ScrollAnimation>
                );
              })}
            </div>
          </ScrollAnimation>

          {/* Important Message */}
          <ScrollAnimation direction="scale" delay={800}>
            <div className="mt-12 sm:mt-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-2xl sm:rounded-3xl p-6 sm:p-8 text-white text-center">
              <Shield className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 sm:mb-6" />
              <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 sm:mb-4">
                Reporting Guidelines for Students
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 text-left">
                <div>
                  <h4 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 flex items-center gap-2">
                    <Heart className="w-4 h-4 sm:w-5 sm:h-5" />
                    What to Report:
                  </h4>
                  <ul className="space-y-1 sm:space-y-2 opacity-90 text-sm sm:text-base">
                    <li>• Someone selling drugs near school</li>
                    <li>• Friends or classmates using drugs</li>
                    <li>• Adults offering drugs to students</li>
                    <li>• Suspicious drug-related activities</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 flex items-center gap-2">
                    <Shield className="w-4 h-4 sm:w-5 sm:h-5" />
                    How to Stay Safe:
                  </h4>
                  <ul className="space-y-1 sm:space-y-2 opacity-90 text-sm sm:text-base">
                    <li>• You can report anonymously</li>
                    <li>• Tell a trusted adult first</li>
                    <li>• Don't confront drug users directly</li>
                    <li>• Your safety comes first</li>
                  </ul>
                </div>
              </div>
              <p className="text-base sm:text-lg opacity-80 mt-4 sm:mt-6">
                Remember: Reporting drug activities is not "snitching" - it's being a responsible citizen who cares about community safety!
              </p>
            </div>
          </ScrollAnimation>
        </div>
      </div>
    </section>
  );
};

export default Resources;