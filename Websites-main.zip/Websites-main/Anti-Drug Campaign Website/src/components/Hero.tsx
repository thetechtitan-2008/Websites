import React, { useState, useEffect } from 'react';
import { ArrowDown, Heart, Star, Shield } from 'lucide-react';
import ScrollAnimation from './ScrollAnimation';

const Hero: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  const backgroundImages = [
    'https://images.pexels.com/photos/1516440/pexels-photo-1516440.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    'https://images.pexels.com/photos/1454360/pexels-photo-1454360.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
  ];

  useEffect(() => {
    setIsVisible(true);
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % backgroundImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const scrollToNext = () => {
    const element = document.getElementById('why-say-no');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        {backgroundImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-30' : 'opacity-0'
            }`}
          >
            <img
              src={image}
              alt={`Background ${index + 1}`}
              className="w-full h-full object-cover"
            />
          </div>
        ))}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-400/80 via-green-400/80 to-yellow-400/80 dark:from-purple-600/80 dark:via-blue-600/80 dark:to-indigo-600/80" />
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <Heart className="absolute top-16 left-4 sm:top-20 sm:left-20 w-6 h-6 sm:w-8 sm:h-8 text-pink-300 animate-bounce" style={{ animationDelay: '0s' }} />
        <Star className="absolute top-32 right-8 sm:top-40 sm:right-32 w-4 h-4 sm:w-6 sm:h-6 text-yellow-300 animate-pulse" style={{ animationDelay: '1s' }} />
        <Shield className="absolute bottom-24 left-4 sm:bottom-32 sm:left-16 w-8 h-8 sm:w-10 sm:h-10 text-blue-300 animate-bounce" style={{ animationDelay: '2s' }} />
        <Heart className="absolute bottom-16 right-4 sm:bottom-20 sm:right-20 w-5 h-5 sm:w-7 sm:h-7 text-green-300 animate-pulse" style={{ animationDelay: '3s' }} />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <ScrollAnimation direction="scale" duration={1000}>
          <h1 className="text-3xl sm:text-5xl md:text-7xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent drop-shadow-lg leading-tight">
            Choose Life,
            <br />
            Say No to Drugs!
          </h1>
        </ScrollAnimation>
          
        <ScrollAnimation direction="up" delay={300}>
          <p className="text-lg sm:text-xl md:text-2xl mb-6 sm:mb-8 text-white font-semibold drop-shadow-md">
            Be Smart. Be Strong. Be Drug-Free.
          </p>
        </ScrollAnimation>
          
        <ScrollAnimation direction="up" delay={600}>
          <p className="text-base sm:text-lg md:text-xl mb-8 sm:mb-12 text-white/90 max-w-2xl mx-auto leading-relaxed">
            This space is made for YOU — to learn, make smart choices, and build an amazing future.
          </p>
          
          <button
            onClick={scrollToNext}
            className="group bg-white text-blue-600 px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-base sm:text-lg hover:bg-blue-50 transition-all duration-300 shadow-xl hover:shadow-2xl hover:scale-105"
          >
            Explore More
            <ArrowDown className="inline-block ml-2 w-4 h-4 sm:w-5 sm:h-5 group-hover:animate-bounce" />
          </button>
        </ScrollAnimation>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-4 sm:bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-5 h-8 sm:w-6 sm:h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-2 sm:h-3 bg-white/50 rounded-full mt-1 sm:mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;