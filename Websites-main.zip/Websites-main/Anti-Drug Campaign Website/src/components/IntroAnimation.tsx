import React, { useState, useEffect } from 'react';
import { Shield, Sparkles, Star, Heart } from 'lucide-react';

interface IntroAnimationProps {
  onComplete: () => void;
}

const IntroAnimation: React.FC<IntroAnimationProps> = ({ onComplete }) => {
  const [currentPhase, setCurrentPhase] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const phases = [
      { duration: 1000, phase: 1 }, // Logo appears (1s)
      { duration: 2500, phase: 2 }, // All content appears together (2.5s)
      { duration: 500, phase: 3 }, // Fade out (0.5s)
    ];

    let timeoutId: NodeJS.Timeout;
    let currentIndex = 0;

    const nextPhase = () => {
      if (currentIndex < phases.length) {
        setCurrentPhase(phases[currentIndex].phase);
        timeoutId = setTimeout(() => {
          currentIndex++;
          if (currentIndex < phases.length) {
            nextPhase();
          } else {
            setIsVisible(false);
            setTimeout(onComplete, 300);
          }
        }, phases[currentIndex].duration);
      }
    };

    // Start the animation sequence
    setTimeout(nextPhase, 200);

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [onComplete]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-32 h-32 bg-white/5 rounded-full animate-pulse" style={{ animationDelay: '0s' }}></div>
        <div className="absolute top-40 right-32 w-24 h-24 bg-yellow-400/10 rounded-full animate-bounce" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-32 left-16 w-40 h-40 bg-pink-400/5 rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute bottom-20 right-20 w-28 h-28 bg-blue-400/10 rounded-full animate-bounce" style={{ animationDelay: '3s' }}></div>
        
        {/* Floating Icons */}
        <Sparkles className="absolute top-32 left-1/4 w-8 h-8 text-yellow-300/30 animate-spin" style={{ animationDuration: '4s', animationDelay: '1s' }} />
        <Star className="absolute top-1/4 right-1/4 w-6 h-6 text-pink-300/40 animate-pulse" style={{ animationDelay: '2s' }} />
        <Heart className="absolute bottom-1/3 left-1/3 w-7 h-7 text-red-300/30 animate-bounce" style={{ animationDelay: '3s' }} />
        <Shield className="absolute bottom-1/4 right-1/3 w-8 h-8 text-blue-300/40 animate-pulse" style={{ animationDelay: '4s' }} />
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center px-4 max-w-6xl mx-auto">
        {/* Logo */}
        <div className={`transition-all duration-1000 ${
          currentPhase >= 1 ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-75 translate-y-5'
        }`}>
          <div className="relative mb-6">
            <div className="relative inline-block">
              <div className="w-24 h-24 md:w-32 md:h-32 bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-2xl">
                <Shield className="w-12 h-12 md:w-16 md:h-16 text-white" />
              </div>
              
              {/* Animated rings around logo */}
              <div className="absolute inset-0 w-24 h-24 md:w-32 md:h-32 border-4 border-white/20 rounded-full animate-ping"></div>
              <div className="absolute inset-0 w-24 h-24 md:w-32 md:h-32 border-2 border-yellow-400/30 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
              
              {/* Orbiting elements */}
              <div className="absolute inset-0 w-24 h-24 md:w-32 md:h-32 animate-spin" style={{ animationDuration: '8s' }}>
                <Star className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-6 h-6 text-yellow-400" />
                <Heart className="absolute top-1/2 -right-2 transform -translate-y-1/2 w-5 h-5 text-pink-400" />
                <Sparkles className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-5 h-5 text-blue-400" />
                <Shield className="absolute top-1/2 -left-2 transform -translate-y-1/2 w-4 h-4 text-green-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Title and Content - All appear together */}
        <div className={`transition-all duration-800 ${
          currentPhase >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 leading-tight">
            <span className="block bg-gradient-to-r from-yellow-300 via-orange-400 to-red-400 bg-clip-text text-transparent drop-shadow-lg animate-pulse">
              Anti-Drug Campaign:
            </span>
            <span className="block bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent drop-shadow-lg mt-2">
              Power Over Poison
            </span>
          </h1>

          
          <div className="relative mb-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl px-8 py-6 inline-block border border-white/20">
              <p className="text-xl md:text-3xl text-white font-semibold">
                Choose Life. Choose Health. Choose Your Future.
              </p>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-4 -left-4 w-8 h-8 bg-yellow-400/30 rounded-full animate-bounce"></div>
            <div className="absolute -bottom-4 -right-4 w-6 h-6 bg-pink-400/30 rounded-full animate-pulse"></div>
          </div>

          <div className="relative mb-4">
            <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-sm rounded-xl px-6 py-4 inline-block border border-purple-400/30">
              <p className="text-lg md:text-xl text-purple-200 font-medium">
                Campaign by the Students of
              </p>
              <p className="text-xl md:text-2xl text-white font-bold mt-1">
                Class XII BMV
              </p>
            </div>
            
            {/* Sparkle effects */}
            <Sparkles className="absolute -top-2 -right-2 w-6 h-6 text-yellow-300 animate-spin" />
            <Star className="absolute -bottom-2 -left-2 w-5 h-5 text-pink-300 animate-pulse" />
          </div>
        </div>

        {/* Loading indicator */}
        <div className={`mt-6 transition-all duration-500 ${
          currentPhase >= 2 ? 'opacity-100' : 'opacity-0'
        }`}>
          <div className="flex justify-center items-center gap-2">
            <div className="w-3 h-3 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
            <div className="w-3 h-3 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-3 h-3 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
          </div>
          <p className="text-white/70 text-sm mt-4 animate-pulse">
            Preparing your journey to a drug-free life...
          </p>
        </div>
      </div>

      {/* Fade out overlay */}
      <div className={`absolute inset-0 bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 transition-opacity duration-500 ${
        currentPhase >= 3 ? 'opacity-100' : 'opacity-0'
      }`}></div>
    </div>
  );
};

export default IntroAnimation;