import React, { useState, useEffect } from 'react';
import { Shield, Heart, Star, CheckCircle, Sparkles, ChevronDown, ChevronUp, Users } from 'lucide-react';
import ScrollAnimation from './ScrollAnimation';

const Pledge: React.FC = () => {
  const [name, setName] = useState('');
  const [hasPledged, setHasPledged] = useState(false);
  const [animatingStars, setAnimatingStars] = useState<number[]>([]);
  const [showAllPledges, setShowAllPledges] = useState(false);
  
  // Initial pledges that are always visible
  const initialPledges = [
    'Abhiram R Ajay', 'Adityan B', 'Devanarayanan PR', 'Naveen Sai', 'Ujwal Prasad', 'Aniket Raveendran',
    'Adityasankar M', 'Sahal S', 'Adwait Sankar', 'Aneasow P Anish', 'Sooryan MC', 'Badrinath R'
  ];
  
  // Additional pledges that get added over time
  const [additionalPledges, setAdditionalPledges] = useState<string[]>(() => {
    const saved = localStorage.getItem('additionalPledges');
    return saved ? JSON.parse(saved) : [];
  });
  
  // Combined pledges for display
  const allPledges = [...initialPledges, ...additionalPledges];
  const displayedPledges = showAllPledges ? allPledges : initialPledges;

  // Save additional pledges to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('additionalPledges', JSON.stringify(additionalPledges));
  }, [additionalPledges]);

  const handleStarClick = (index: number) => {
    setAnimatingStars(prev => [...prev, index]);
    setTimeout(() => {
      setAnimatingStars(prev => prev.filter(i => i !== index));
    }, 1000);
  };

  const handleCardClick = (index: number) => {
    handleStarClick(index);
  };

  const handlePledge = () => {
    if (name.trim()) {
      setAdditionalPledges([...additionalPledges, name]);
      setHasPledged(true);
      setTimeout(() => {
        setHasPledged(false);
        setName('');
      }, 3000);
    }
  };

  const pledgeText = "I choose health. I choose happiness. I choose a drug-free life.";

  return (
    <section id="pledge" className="py-12 sm:py-20 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4">
        <ScrollAnimation direction="fade" className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-400 dark:to-pink-400 bg-clip-text text-transparent">
            Take the Pledge
          </h2>
          <p className="text-lg sm:text-xl text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            Join thousands of students who have committed to living a drug-free life. Your future self will thank you!
          </p>
        </ScrollAnimation>

        <ScrollAnimation direction="up" delay={300} className="max-w-4xl mx-auto">
          {/* Pledge Form */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 md:p-12 mb-8 sm:mb-12">
            {!hasPledged ? (
              <div className="text-center">
                <Shield className="w-12 h-12 sm:w-16 sm:h-16 text-purple-600 mx-auto mb-4 sm:mb-6" />
                
                <div className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900 dark:to-pink-900 rounded-xl sm:rounded-2xl p-6 sm:p-8 mb-6 sm:mb-8">
                  <h3 className="text-xl sm:text-2xl md:text-3xl font-bold mb-4 sm:mb-6 text-gray-800 dark:text-white">
                    The Drug-Free Pledge
                  </h3>
                  <p className="text-lg sm:text-xl md:text-2xl text-gray-700 dark:text-gray-300 italic leading-relaxed">
                    "{pledgeText}"
                  </p>
                </div>

                <div className="mb-6 sm:mb-8">
                  <label htmlFor="name" className="block text-base sm:text-lg font-semibold mb-3 sm:mb-4 text-gray-700 dark:text-gray-300">
                    Enter your name to sign the pledge:
                  </label>
                  <input
                    type="text"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full max-w-md mx-auto px-4 sm:px-6 py-3 sm:py-4 text-base sm:text-lg border-2 border-purple-200 dark:border-purple-600 dark:bg-gray-700 dark:text-white rounded-xl focus:border-purple-500 focus:outline-none transition-colors"
                    placeholder="Your name here..."
                  />
                </div>

                <button
                  onClick={handlePledge}
                  disabled={!name.trim()}
                  className={`px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-base sm:text-lg transition-all duration-200 shadow-lg hover:shadow-xl ${
                    name.trim()
                      ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:scale-105'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  <Heart className="inline-block w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                  Sign the Pledge
                </button>
              </div>
            ) : (
              <div className="text-center">
                <div className="relative">
                  <Sparkles className="w-16 h-16 sm:w-20 sm:h-20 text-purple-600 mx-auto mb-4 sm:mb-6 animate-pulse" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <CheckCircle className="w-8 h-8 sm:w-12 sm:h-12 text-green-500 animate-bounce" />
                  </div>
                </div>
                
                <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 sm:mb-4 text-gray-800 dark:text-white">
                  Congratulations, {name}!
                </h3>
                <p className="text-lg sm:text-xl text-gray-700 dark:text-gray-300 mb-4 sm:mb-6">
                  You've made an amazing commitment to your health and future!
                </p>
                <div className="bg-gradient-to-r from-green-400 to-blue-500 text-white rounded-xl sm:rounded-2xl p-4 sm:p-6">
                  <p className="text-base sm:text-lg font-semibold">
                    Your name has been added to our Pledge Wall of Champions!
                  </p>
                </div>
              </div>
            )}
          </div>
        </ScrollAnimation>

        {/* Pledge Wall */}
        <ScrollAnimation direction="scale" delay={600}>
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl sm:rounded-3xl p-6 sm:p-8 md:p-12 text-white">
            <div className="text-center mb-6 sm:mb-8">
              <Star className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4" />
              <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 sm:mb-4">
                Pledge Wall of Champions
              </h3>
              <p className="text-lg sm:text-xl opacity-90 mb-3 sm:mb-4">
                These amazing students have committed to a drug-free life:
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 mb-4 sm:mb-6">
                <div className="flex items-center gap-2 bg-white/20 rounded-full px-3 sm:px-4 py-2">
                  <Users className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="font-semibold text-sm sm:text-base">{allPledges.length} Champions</span>
                </div>
                {additionalPledges.length > 0 && (
                  <div className="flex items-center gap-2 bg-green-400/30 rounded-full px-3 sm:px-4 py-2">
                    <Star className="w-3 h-3 sm:w-4 sm:h-4" />
                    <span className="text-xs sm:text-sm font-medium">{additionalPledges.length} New Today!</span>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
              {displayedPledges.map((pledger, index) => {
                const isNewPledge = index >= initialPledges.length;
                return (
                <div
                  key={index}
                  className={`backdrop-blur-sm rounded-xl p-3 sm:p-4 text-center hover:bg-white/30 transition-all duration-200 hover:scale-105 cursor-pointer relative ${
                    isNewPledge ? 'bg-green-400/30 border-2 border-green-300/50' : 'bg-white/20'
                  }`}
                  onClick={() => handleCardClick(index)}
                >
                  {isNewPledge && (
                    <div className="absolute -top-1 -right-1 sm:-top-2 sm:-right-2 bg-green-400 text-green-900 text-xs font-bold px-1 sm:px-2 py-0.5 sm:py-1 rounded-full">
                      NEW
                    </div>
                  )}
                  <div 
                    className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center mx-auto mb-2 cursor-pointer relative ${
                      isNewPledge ? 'bg-green-400' : 'bg-yellow-400'
                    }`}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleStarClick(index);
                    }}
                  >
                    <Star className={`w-3 h-3 sm:w-4 sm:h-4 transition-all duration-300 ${
                      isNewPledge ? 'text-green-800' : 'text-yellow-800'
                    } ${
                      animatingStars.includes(index) ? 'animate-spin scale-150' : ''
                    }`} />
                    {animatingStars.includes(index) && (
                      <>
                        <div className={`absolute inset-0 rounded-full animate-ping opacity-75 ${
                          isNewPledge ? 'bg-green-300' : 'bg-yellow-300'
                        }`}></div>
                        <div className={`absolute -top-1 -right-1 w-2 h-2 sm:w-3 sm:h-3 rounded-full animate-bounce ${
                          isNewPledge ? 'bg-green-300' : 'bg-yellow-300'
                        }`}></div>
                        <div className={`absolute -bottom-1 -left-1 w-1 h-1 sm:w-2 sm:h-2 rounded-full animate-pulse ${
                          isNewPledge ? 'bg-green-400' : 'bg-yellow-400'
                        }`}></div>
                        <div className="absolute top-0 left-0 w-full h-full">
                          <Star className={`w-4 h-4 sm:w-6 sm:h-6 absolute -top-1 -left-1 animate-pulse opacity-50 ${
                            isNewPledge ? 'text-green-300' : 'text-yellow-300'
                          }`} />
                        </div>
                      </>
                    )}
                  </div>
                  <p className="font-semibold text-xs sm:text-sm">{pledger}</p>
                </div>
              );
              })}
            </div>
            
            {/* See All / Show Less Button */}
            {additionalPledges.length > 0 && (
              <div className="text-center mt-6 sm:mt-8">
                <button
                  onClick={() => setShowAllPledges(!showAllPledges)}
                  className="bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white px-4 sm:px-6 py-2 sm:py-3 rounded-full font-semibold transition-all duration-200 hover:scale-105 flex items-center gap-2 mx-auto text-sm sm:text-base"
                >
                  {showAllPledges ? (
                    <>
                      <ChevronUp className="w-4 h-4 sm:w-5 sm:h-5" />
                      Show Less
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-4 h-4 sm:w-5 sm:h-5" />
                      See All {allPledges.length} Champions
                    </>
                  )}
                </button>
                
                {!showAllPledges && (
                  <p className="text-white/70 text-xs sm:text-sm mt-2">
                    {additionalPledges.length} more champions have joined today!
                  </p>
                )}
              </div>
            )}
          </div>
        </ScrollAnimation>
      </div>
    </section>
  );
};

export default Pledge;