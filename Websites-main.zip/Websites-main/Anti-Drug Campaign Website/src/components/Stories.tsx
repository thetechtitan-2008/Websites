import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Quote, Heart, Star } from 'lucide-react';
import ScrollAnimation from './ScrollAnimation';

const Stories: React.FC = () => {
  const [currentStory, setCurrentStory] = useState(0);

  const stories = [
    {
      name: 'Aravind',
      age: 14,
      title: 'The Sports Star',
      image: 'https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg?auto=compress&cs=tinysrgb&w=400&h=400',
      story: 'I used to be the fastest runner in my school. When some older kids offered me drugs, I thought it would make me even better. Instead, I got sick and couldn\'t run for months. I learned that my natural talent was already amazing!',
      lesson: 'Real strength comes from within, not from substances.',
      color: 'from-blue-500 to-green-500',
    },
    {
      name: 'Meera',
      age: 13,
      title: 'The Artist',
      image: 'https://images.pexels.com/photos/8613317/pexels-photo-8613317.jpeg?auto=compress&cs=tinysrgb&w=400&h=400',
      story: 'I love drawing and painting. A friend said drugs would make me more creative, but when I tried them, I couldn\'t focus on my art at all. My drawings became messy and I felt terrible. Now I create beautiful art with a clear mind!',
      lesson: 'True creativity flows from a healthy, clear mind.',
      color: 'from-purple-500 to-pink-500',
    },
    {
      name: 'Jayan',
      age: 15,
      title: 'The Leader',
      image: 'https://images.pexels.com/photos/8613200/pexels-photo-8613200.jpeg?auto=compress&cs=tinysrgb&w=400&h=400',
      story: 'I was student council president and really popular. When I started using drugs, I lost my friends\' respect and my grades dropped. I realized that being a real leader means making good choices and inspiring others positively.',
      lesson: 'Leadership means setting a positive example for others.',
      color: 'from-orange-500 to-red-500',
    },
    {
      name: 'Sreeram',
      age: 12,
      title: 'The Gamer',
      image: 'https://images.pexels.com/photos/8613271/pexels-photo-8613271.jpeg?auto=compress&cs=tinysrgb&w=400&h=400',
      story: 'I love playing video games and wanted to stay awake longer to play more. Someone gave me pills that kept me awake, but I got addicted and couldn\'t enjoy gaming anymore. Now I play for fun and get proper rest!',
      lesson: 'Balance and moderation make life more enjoyable.',
      color: 'from-green-500 to-blue-500',
    },
  ];

  const nextStory = () => {
    setCurrentStory((prev) => (prev + 1) % stories.length);
  };

  const prevStory = () => {
    setCurrentStory((prev) => (prev - 1 + stories.length) % stories.length);
  };

  const currentStoryData = stories[currentStory];

  return (
    <section id="stories" className="py-12 sm:py-20 bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4">
        <ScrollAnimation direction="fade" className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-orange-600 to-red-600 dark:from-orange-400 dark:to-red-400 bg-clip-text text-transparent">
            Real Stories from Real Students
          </h2>
          <p className="text-lg sm:text-xl text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            These are stories from students just like you who made the smart choice to say no to drugs.
          </p>
        </ScrollAnimation>

        <ScrollAnimation direction="scale" delay={300} className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Story Card */}
            <div className={`bg-white dark:bg-gray-800 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden transition-all duration-500 transform hover:scale-105`}>
              <div className={`h-1 sm:h-2 bg-gradient-to-r ${currentStoryData.color}`}></div>
              
              <div className="p-6 sm:p-8 md:p-12">
                <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 mb-6 sm:mb-8">
                  <div className="relative">
                    <img
                      src={currentStoryData.image}
                      alt={currentStoryData.name}
                      className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-full object-cover border-4 border-white shadow-lg"
                    />
                    <div className={`absolute -top-1 -right-1 sm:-top-2 sm:-right-2 w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r ${currentStoryData.color} rounded-full flex items-center justify-center`}>
                      <Star className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                    </div>
                  </div>
                  
                  <div className="text-center sm:text-left">
                    <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-800 dark:text-white">{currentStoryData.name}</h3>
                    <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300">Age {currentStoryData.age} • {currentStoryData.title}</p>
                  </div>
                </div>

                <div className="relative mb-6 sm:mb-8">
                  <Quote className="w-6 h-6 sm:w-8 sm:h-8 text-gray-300 dark:text-gray-500 absolute -top-1 -left-1 sm:-top-2 sm:-left-2" />
                  <p className="text-base sm:text-lg md:text-xl text-gray-700 dark:text-gray-300 leading-relaxed pl-4 sm:pl-6 italic">
                    "{currentStoryData.story}"
                  </p>
                </div>

                <div className={`bg-gradient-to-r ${currentStoryData.color} rounded-xl sm:rounded-2xl p-4 sm:p-6 text-white`}>
                  <div className="flex items-center gap-2 mb-2">
                    <Heart className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span className="font-semibold text-sm sm:text-base">Key Lesson:</span>
                  </div>
                  <p className="text-sm sm:text-base md:text-lg">{currentStoryData.lesson}</p>
                </div>
              </div>
            </div>

            {/* Navigation Buttons */}
            <button
              onClick={prevStory}
              className="absolute left-2 sm:left-4 top-1/2 transform -translate-y-1/2 bg-white dark:bg-gray-700 rounded-full p-2 sm:p-3 shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-110"
            >
              <ChevronLeft className="w-4 h-4 sm:w-6 sm:h-6 text-gray-600 dark:text-gray-300" />
            </button>
            
            <button
              onClick={nextStory}
              className="absolute right-2 sm:right-4 top-1/2 transform -translate-y-1/2 bg-white dark:bg-gray-700 rounded-full p-2 sm:p-3 shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-110"
            >
              <ChevronRight className="w-4 h-4 sm:w-6 sm:h-6 text-gray-600 dark:text-gray-300" />
            </button>
          </div>

          {/* Story Indicators */}
          <div className="flex justify-center gap-2 mt-6 sm:mt-8">
            {stories.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentStory(index)}
                className={`w-2 h-2 sm:w-3 sm:h-3 rounded-full transition-all duration-200 ${
                  index === currentStory ? 'bg-orange-500 scale-125' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </ScrollAnimation>
      </div>
    </section>
  );
};

export default Stories;