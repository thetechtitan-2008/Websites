import React from 'react';
import { Shield, Mail, ExternalLink, Heart, Phone, MessageSquare } from 'lucide-react';
import ScrollAnimation from './ScrollAnimation';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 dark:bg-gray-900 text-white py-8 sm:py-12 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {/* Brand Section */}
          <div>
            <div className="flex items-center gap-2 mb-3 sm:mb-4">
              <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-blue-400" />
              <h3 className="text-xl sm:text-2xl font-bold">Drug-Free Life</h3>
            </div>
            <p className="text-gray-300 mb-3 sm:mb-4 text-sm sm:text-base">
              Empowering students to make smart, healthy choices for a brighter future.
            </p>
            <div className="flex items-center gap-2 text-pink-400">
              <Heart className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="text-xs sm:text-sm">Made with love for students</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg sm:text-xl font-bold mb-3 sm:mb-4">Quick Links</h4>
            <ul className="space-y-1 sm:space-y-2">
              <li>
                <a href="#home" className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                  Home
                </a>
              </li>
              <li>
                <a href="#why-say-no" className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                  Why Say No?
                </a>
              </li>
              <li>
                <a href="#stories" className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                  Real Stories
                </a>
              </li>
              <li>
                <a href="#pledge" className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                  Take Pledge
                </a>
              </li>
              <li>
                <a href="#resources" className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                  Get Help
                </a>
              </li>
            </ul>
          </div>

          {/* Emergency Support */}
          <div className="sm:col-span-2 lg:col-span-1">
            <h4 className="text-lg sm:text-xl font-bold mb-3 sm:mb-4">Emergency Support</h4>
            <div className="space-y-2 sm:space-y-3">
              <div className="flex items-center gap-2">
                <Phone className="w-3 h-3 sm:w-4 sm:h-4 text-green-400" />
                <span className="text-xs sm:text-sm">Crisis Line: 112</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageSquare className="w-3 h-3 sm:w-4 sm:h-4 text-blue-400" />
                <span className="text-xs sm:text-sm">Text HOME to 741741</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3 h-3 sm:w-4 sm:h-4 text-purple-400" />
                <span className="text-xs sm:text-sm">abhiramrajay2022@gmail.com</span>
              </div>
            </div>
            
            <div className="mt-4 sm:mt-6">
              <button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 sm:px-6 py-2 sm:py-3 rounded-full font-semibold hover:scale-105 transition-all duration-200 shadow-lg flex items-center gap-2 text-sm sm:text-base">
                Take Quiz
                <ExternalLink className="w-3 h-3 sm:w-4 sm:h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Elegant Credits Section */}
        <div className="relative mt-6 sm:mt-8 pt-6 sm:pt-8 border-t border-gray-700">
          {/* Animated Background Elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -bottom-10 -right-10 w-24 h-24 sm:w-32 sm:h-32 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full animate-pulse"></div>
            <div className="absolute -bottom-5 -left-5 w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-r from-pink-500/10 to-orange-500/10 rounded-full animate-bounce" style={{ animationDelay: '1s' }}></div>
            <div className="absolute bottom-16 right-1/4 w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-green-500/10 to-teal-500/10 rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
          </div>
          
          <div className="relative z-10">
            <ScrollAnimation direction="up" delay={200}>
              <div className="flex flex-col gap-4 sm:gap-6">
                {/* Campaign Credit */}
                <div className="text-center">
                  <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm rounded-xl sm:rounded-2xl px-4 sm:px-6 py-3 sm:py-4 border border-blue-400/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 inline-block">
                    <div className="flex items-center gap-2 sm:gap-3 mb-1 sm:mb-2 justify-center">
                      <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full flex items-center justify-center">
                        <Shield className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                      </div>
                      <span className="text-blue-300 font-semibold text-xs sm:text-sm uppercase tracking-wider">Campaign by</span>
                    </div>
                    <p className="text-lg sm:text-xl md:text-2xl font-bold bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-transparent">
                      Students of Class XII, BMVK
                    </p>
                  </div>
                </div>
                
                {/* Website Credit */}
                <div className="text-center">
                  <div className="bg-gradient-to-r from-pink-500/20 to-orange-500/20 backdrop-blur-sm rounded-xl sm:rounded-2xl px-4 sm:px-6 py-3 sm:py-4 border border-pink-400/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 inline-block">
                    <div className="flex items-center gap-2 sm:gap-3 mb-1 sm:mb-2 justify-center">
                      <span className="text-pink-300 font-semibold text-xs sm:text-sm uppercase tracking-wider">Website Created by</span>
                      <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-pink-400 to-orange-400 rounded-full flex items-center justify-center">
                        <Heart className="w-3 h-3 sm:w-4 sm:h-4 text-white animate-pulse" />
                      </div>
                    </div>
                    <p className="text-lg sm:text-xl md:text-2xl font-bold bg-gradient-to-r from-pink-300 to-orange-300 bg-clip-text text-transparent">
                      Abhiram R Ajay
                    </p>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
            
            {/* Decorative Elements */}
            <ScrollAnimation direction="fade" delay={400}>
              <div className="flex justify-center mt-4 sm:mt-6">
                <div className="flex items-center gap-2 sm:gap-4">
                  <div className="w-8 h-0.5 sm:w-12 sm:h-0.5 bg-gradient-to-r from-transparent via-blue-400 to-transparent"></div>
                  <div className="w-2 h-2 sm:w-3 sm:h-3 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full animate-pulse"></div>
                  <div className="w-4 h-0.5 sm:w-6 sm:h-0.5 bg-gradient-to-r from-blue-400 to-pink-400"></div>
                  <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-gradient-to-r from-pink-400 to-orange-400 rounded-full animate-bounce"></div>
                  <div className="w-4 h-0.5 sm:w-6 sm:h-0.5 bg-gradient-to-r from-pink-400 to-blue-400"></div>
                  <div className="w-2 h-2 sm:w-3 sm:h-3 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
                  <div className="w-8 h-0.5 sm:w-12 sm:h-0.5 bg-gradient-to-r from-transparent via-pink-400 to-transparent"></div>
                </div>
              </div>
            </ScrollAnimation>
            
            {/* Final Message */}
            <ScrollAnimation direction="scale" delay={600}>
              <div className="text-center mt-4 sm:mt-6">
                <p className="text-gray-400 text-xs sm:text-sm italic">
                  "Together, we choose a brighter, drug-free future" ✨
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-6 sm:mt-8 pt-6 sm:pt-8 text-center">
          <p className="text-gray-400 text-xs sm:text-sm">
            &copy; 2024 Drug-Free Life Campaign. Made for educational purposes. 
          </p>
          <p className="text-gray-500 text-xs sm:text-sm mt-1 sm:mt-2">
            Remember: You have the power to choose a healthy, drug-free life. We believe in you!
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;