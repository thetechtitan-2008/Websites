import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.c2b8a5ec4b2c409eba9ecbe80bc0438e',
  appName: 'temporal-scribe-suite',
  webDir: 'dist',
  server: {
    url: 'https://c2b8a5ec-4b2c-409e-ba9e-cbe80bc0438e.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  ios: {
    contentInset: 'automatic'
  },
  android: {
    allowMixedContent: true
  }
};

export default config;
