import { useNavigate } from "react-router-dom";
import { ArrowLeft, Pyramid, Palette, Cog, Rocket, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { memo } from "react";

const ERAS = [
  {
    id: "ancient",
    title: "Ancient Civilizations",
    period: "3000 BCE - 500 CE",
    description: "The dawn of recorded history. Pyramids, philosophers, and the birth of writing.",
    icon: Pyramid,
    color: "hsl(33, 48%, 46%)",
    highlights: [
      "Construction of the Great Pyramid (2560 BCE)",
      "Founding of Rome (753 BCE)",
      "Library of Alexandria established (288 BCE)",
      "Fall of the Western Roman Empire (476 CE)",
    ],
  },
  {
    id: "renaissance",
    title: "Renaissance",
    period: "1400 - 1600 CE",
    description: "The rebirth of art, science, and human potential.",
    icon: Palette,
    color: "hsl(33, 48%, 46%)",
    highlights: [
      "Gutenberg prints first book (1455)",
      "Leonardo da Vinci paints Mona Lisa (1503)",
      "Copernicus proposes heliocentric model (1543)",
      "Shakespeare writes Hamlet (1600)",
    ],
  },
  {
    id: "industrial",
    title: "Industrial Revolution",
    period: "1760 - 1900 CE",
    description: "Steam, steel, and the transformation of human labor.",
    icon: Cog,
    color: "hsl(33, 48%, 46%)",
    highlights: [
      "James Watt improves steam engine (1769)",
      "First railway opens (1825)",
      "Edison patents light bulb (1879)",
      "First powered flight attempt (1890s)",
    ],
  },
  {
    id: "space-age",
    title: "Space Age",
    period: "1950 - 2000 CE",
    description: "Humanity reaches for the stars and invents the digital world.",
    icon: Rocket,
    color: "hsl(185, 98%, 76%)",
    highlights: [
      "Sputnik launches (1957)",
      "Moon landing (1969)",
      "Personal computers arrive (1970s-80s)",
      "World Wide Web created (1989)",
    ],
  },
  {
    id: "future",
    title: "The Future",
    period: "2025+ CE",
    description: "AI, climate action, and the next chapter of human evolution.",
    icon: Sparkles,
    color: "hsl(185, 98%, 76%)",
    highlights: [
      "Artificial General Intelligence emerges",
      "Carbon neutrality achieved globally",
      "First permanent Mars colony established",
      "Quantum computing becomes mainstream",
    ],
  },
];

function EraExplorer() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen py-8 sm:py-12 px-3 sm:px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <Button
          variant="ghost"
          onClick={() => navigate("/", { state: { fromPage: true } })}
          className="mb-8 hover:bg-primary/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Return to Study
        </Button>

        <div className="text-center mb-8 sm:mb-12 px-2">
          <h1 className="text-3xl sm:text-4xl md:text-6xl font-journal text-primary mb-3 sm:mb-4 luxury-glow">
            Era Explorer
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground font-serif italic">
            Navigate the centuries. Witness human progress unfold.
          </p>
        </div>

        {/* Eras Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 md:gap-8">
          {ERAS.map((era, index) => {
            const Icon = era.icon;
            return (
              <Card
                key={era.id}
                className="group relative overflow-hidden border-2 hover:border-primary/50 transition-all duration-standard cursor-pointer hover:shadow-lifted"
                style={{
                  animationDelay: `${index * 100}ms`,
                }}
              >
                {/* Color accent bar */}
                <div
                  className="absolute top-0 left-0 right-0 h-1"
                  style={{ backgroundColor: era.color }}
                />

                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <div
                      className="p-3 rounded-lg transition-all duration-standard group-hover:scale-110"
                      style={{ backgroundColor: `${era.color}20` }}
                    >
                      <Icon
                        className="w-6 h-6"
                        style={{ color: era.color }}
                      />
                    </div>
                    <span className="text-xs font-serif text-muted-foreground">
                      {era.period}
                    </span>
                  </div>
                  
                  <CardTitle className="text-2xl font-journal group-hover:text-primary transition-colors">
                    {era.title}
                  </CardTitle>
                  
                  <CardDescription className="font-serif">
                    {era.description}
                  </CardDescription>
                </CardHeader>

                <CardContent>
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold text-foreground mb-3">
                      Key Moments:
                    </h4>
                    <ul className="space-y-2">
                      {era.highlights.map((highlight, idx) => (
                        <li
                          key={idx}
                          className="text-sm text-muted-foreground font-serif flex items-start"
                        >
                          <span className="text-primary mr-2">•</span>
                          <span>{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Explore button */}
                  <Button
                    variant="outline"
                    className="w-full mt-6 group-hover:bg-primary group-hover:text-primary-foreground transition-all"
                    onClick={() => navigate(`/logbook`)}
                  >
                    Explore Era
                  </Button>
                </CardContent>

                {/* Decorative corner */}
                <div className="absolute bottom-0 right-0 w-20 h-20 opacity-5 group-hover:opacity-10 transition-opacity">
                  <Icon className="w-full h-full" />
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default memo(EraExplorer);
