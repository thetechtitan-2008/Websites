import StudyDesk from "@/components/StudyDesk";

const Index = () => {
  return <StudyDesk />;
};

export default Index;
