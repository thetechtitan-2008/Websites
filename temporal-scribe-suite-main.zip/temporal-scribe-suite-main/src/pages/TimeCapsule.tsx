import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Clock, Lock, Unlock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function TimeCapsule() {
  const navigate = useNavigate();
  const [message, setMessage] = useState("");
  const [unlockDate, setUnlockDate] = useState("");

  const handleSealCapsule = () => {
    if (!message.trim()) {
      toast.error("Please write a message for your future self");
      return;
    }
    if (!unlockDate) {
      toast.error("Please select an unlock date");
      return;
    }

    // Store in localStorage for demo
    const capsule = {
      message,
      unlockDate,
      createdAt: new Date().toISOString(),
    };
    localStorage.setItem("timeCapsule", JSON.stringify(capsule));

    toast.success("Time capsule sealed! It will unlock on " + new Date(unlockDate).toLocaleDateString());
    setMessage("");
    setUnlockDate("");
  };

  const checkCapsule = () => {
    const stored = localStorage.getItem("timeCapsule");
    if (!stored) {
      toast.error("No time capsule found");
      return;
    }

    const capsule = JSON.parse(stored);
    const unlockTime = new Date(capsule.unlockDate);
    const now = new Date();

    if (now >= unlockTime) {
      toast.success("Capsule unlocked!", {
        description: capsule.message,
        duration: 10000,
      });
    } else {
      const daysLeft = Math.ceil((unlockTime.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      toast.info(`Capsule still locked for ${daysLeft} more days`);
    }
  };

  return (
    <div className="min-h-screen py-8 sm:py-12 px-3 sm:px-4 bg-background">
      <div className="max-w-4xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate("/", { state: { fromPage: true } })}
          className="mb-8 hover:bg-primary/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Return to Study
        </Button>

        <div className="text-center mb-8 sm:mb-12 px-2">
          <h1 className="text-3xl sm:text-4xl md:text-6xl font-journal text-primary mb-3 sm:mb-4 luxury-glow">
            Time Capsule
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground font-serif italic">
            Seal a memory for your future self
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 md:gap-8">
          {/* Create Capsule */}
          <Card className="border-2 hover:border-primary/30 transition-colors">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Lock className="w-5 h-5 text-primary" />
                </div>
                <CardTitle className="font-journal">Create Capsule</CardTitle>
              </div>
              <CardDescription className="font-serif">
                Write a message to your future self. Choose when it should be revealed.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="message" className="font-serif">
                  Your Message
                </Label>
                <Textarea
                  id="message"
                  placeholder="Dear future me..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="min-h-[200px] font-serif"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="unlock-date" className="font-serif">
                  Unlock Date
                </Label>
                <Input
                  id="unlock-date"
                  type="date"
                  value={unlockDate}
                  onChange={(e) => setUnlockDate(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>

              <Button
                onClick={handleSealCapsule}
                className="w-full bg-primary hover:bg-primary/90"
              >
                <Lock className="w-4 h-4 mr-2" />
                Seal Time Capsule
              </Button>
            </CardContent>
          </Card>

          {/* Check Capsule */}
          <Card className="border-2 hover:border-accent/30 transition-colors">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-lg bg-accent/10">
                  <Unlock className="w-5 h-5 text-accent" />
                </div>
                <CardTitle className="font-journal">Open Capsule</CardTitle>
              </div>
              <CardDescription className="font-serif">
                Check if your time capsule is ready to be opened.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-center py-8">
                <Clock className="w-32 h-32 text-accent/30 float-slow" />
              </div>

              <p className="text-center text-sm text-muted-foreground font-serif italic">
                Time moves differently for those who wait. Patience is the key that unlocks the future.
              </p>

              <Button
                variant="outline"
                onClick={checkCapsule}
                className="w-full hover:bg-accent/10 hover:text-accent hover:border-accent"
              >
                <Unlock className="w-4 h-4 mr-2" />
                Check My Capsule
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Info Section */}
        <Card className="mt-8 border-primary/20 bg-gradient-to-r from-card to-primary/5">
          <CardContent className="p-6">
            <h3 className="font-journal text-xl text-foreground mb-3">
              About Time Capsules
            </h3>
            <p className="text-sm text-muted-foreground font-serif leading-relaxed">
              A time capsule is a message to your future self. Write down your thoughts, 
              dreams, fears, or predictions. Set a date in the future, and when that day 
              arrives, rediscover who you were and reflect on how you've grown. 
              It's a conversation across time — and the most honest dialogue you'll ever have.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
