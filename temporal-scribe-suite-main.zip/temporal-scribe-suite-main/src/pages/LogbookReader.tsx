import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageFlip } from "@/components/PageFlip";
import { TimelineRibbon } from "@/components/TimelineRibbon";
import { motion } from "framer-motion";

// Sample journal entries
const JOURNAL_PAGES = [
  {
    title: "The First Entry",
    year: 1885,
    content: `My dear friend,

If you are reading this, then my invention has succeeded beyond my wildest dreams. This logbook shall serve as both chronicle and guide through the vast expanse of time itself.

I have witnessed wonders that defy description — cities of gold beneath ancient sands, machines that think, and stars that sing. Yet the greatest marvel remains the human spirit, unchanging across millennia.

Begin your journey with care, for time is a delicate fabric, and every thread we pull may unravel a tapestry we cannot mend.

— H.G.W., London, 1885`,
  },
  {
    title: "Dawn of Civilization",
    year: -3500,
    content: `The Tigris flows eternal beside me as I write these words. I am in Mesopotamia, watching humanity's first cities rise from the fertile plains. The air is thick with clay dust from thousands of brick-makers.

A scribe named Enlil-Bani showed me their new invention today — writing. He pressed a reed stylus into soft clay, creating wedge-shaped marks. "These symbols," he told me with pride, "will outlast our bodies, our cities, even our gods. Knowledge itself becomes immortal."

I realize now that I am witnessing the birth of history itself. Before this moment, humanity lived in an eternal present. After this, we could speak to the future. We could become our own time travelers.`,
  },
  {
    title: "Ancient Wonders",
    year: -2500,
    content: `The Great Pyramid rises like a mountain sculpted by gods. I stood in its shadow today, watching thousands of workers move massive stones with ingenious systems of ramps and levers.

The precision astounds me. How did they achieve such mathematical perfection without our modern instruments? The architects here understand geometry in ways our Victorian minds can barely grasp.

I spoke with a scribe named Amenhotep. Through gestures and rudimentary Egyptian, he explained their belief that these monuments would carry their pharaohs to the stars. Perhaps they understood more about reaching beyond our world than I ever imagined.`,
  },
  {
    title: "The Greek Awakening",
    year: -430,
    content: `Athens buzzes with ideas more revolutionary than any steam engine. I sat in the Agora today listening to Socrates question everything — virtue, knowledge, justice, the very nature of reality.

"I know that I know nothing," he proclaimed to the gathered crowd. This humility, this hunger for truth, this willingness to question every assumption — this is the spark that will illuminate millennia.

Young Plato takes notes nearby. I know what's coming. The Academy. The Republic. Two thousand years of philosophy flowing from this one afternoon of questions. Sometimes the greatest inventions are not things, but ways of thinking.`,
  },
  {
    title: "The Silk Road",
    year: 130,
    content: `I have traveled for months along the Silk Road, that ribbon of commerce connecting Rome to Chang'an. Merchants from a hundred cultures trade not just silk and spices, but ideas, religions, technologies, stories.

A Buddhist monk taught me meditation in a caravanserai. A Roman engineer showed me aqueduct designs. A Chinese alchemist demonstrated gunpowder. A Persian astronomer corrected my star charts.

This is how progress really happens — not in isolation, but through the collision and fusion of diverse minds. The future belongs not to any single civilization, but to the exchange between them all.`,
  },
  {
    title: "Renaissance Dreams",
    year: 1503,
    content: `Florence blooms with genius. I found Leonardo in his workshop today, surrounded by sketches of flying machines and mathematical diagrams. His mind leaps between art, science, and engineering without pause.

"The eye sees what the mind knows," he told me, gesturing at his anatomical drawings. I showed him photographs from my time — his eyes lit up like a child's. "So the camera obscura can capture life itself!" he exclaimed.

We spent hours discussing optics, perspective, and the nature of light. In another age, Leonardo would have been an astronaut, a computer scientist, a film director. Here, he must content himself with paint and parchment. Yet perhaps that limitation forced his genius to burn brighter.`,
  },
  {
    title: "The Printing Revolution",
    year: 1455,
    content: `Gutenberg's workshop smells of ink, metal, and destiny. I watched today as he printed page after page of his Bible, each one identical to the last. The implications make my head spin.

"Knowledge will no longer be locked in monastery libraries," he said, wiping ink from his fingers. "Every man can own books. Every woman can read scripture. Every child can learn from the masters."

He doesn't realize the full scope of what he's unleashed. Printing will enable the Scientific Revolution, the Enlightenment, mass literacy, democracy itself. The pen was always mightier than the sword, but the printing press is mightier than any empire.`,
  },
  {
    title: "The Age of Reason",
    year: 1687,
    content: `I am in Cambridge, holding a copy of Newton's Principia. These pages contain the mathematical laws governing everything from falling apples to orbiting planets. The universe, Newton has shown, operates like a magnificent clockwork.

"I do not frame hypotheses," Newton told me sternly. "I deduce from phenomena and generalize by induction." This is science — not speculation, but rigorous observation and mathematical proof.

Yet even as he explains gravity, Newton spends his nights practicing alchemy and interpreting biblical prophecies. Even our greatest minds contain multitudes, contradictions, mysteries. Perhaps that's what makes us human rather than the machines we increasingly understand.`,
  },
  {
    title: "The Steam Age",
    year: 1851,
    content: `The Crystal Palace Exhibition overwhelms the senses. Glass and iron stretch impossibly upward, housing the mechanical marvels of a hundred nations. Steam engines hiss and clank, locomotives thunder, and everywhere the smell of coal and progress.

I met a young engineer named Isambard. His eyes blazed as he described his vision for bridges that span impossible distances, ships propelled by screws rather than paddles, railways that connect continents.

"We are building the future," he declared. "Soon, distance itself will cease to exist!"

If only he knew how right he would be — though the answer lies not in steam and steel, but in silicon and light.`,
  },
  {
    title: "The Electric Dawn",
    year: 1879,
    content: `Edison's laboratory in Menlo Park glows with possibility. Tonight, I watched as he tested his latest carbon filament. The bulb flickered, steadied, then burned with steady light. The gaslight era is ending.

"We will make electricity so cheap that only the rich will burn candles," Edison joked. But I see the deeper implications — electric light will extend the working day, enable factories to run at night, illuminate cities, and ultimately transform human civilization from diurnal to constant.

A young Serbian engineer named Tesla works in the corner. I know their partnership will not last, but their rivalry will illuminate the world — quite literally.`,
  },
  {
    title: "The Wright Moment",
    year: 1903,
    content: `Kill Devil Hills, North Carolina. The wind howls across the dunes. Wilbur lies prone on the lower wing of their flying machine while Orville prepares to push.

The engine sputters to life. The propellers blur. The machine rolls forward, picks up speed, and then — impossibly — lifts into the air. Twelve seconds. One hundred twenty feet. Humanity's first powered flight.

The brothers are already discussing improvements, longer flights, better engines. They don't realize they've just made every point on Earth accessible. In a century, their descendants will walk on the moon. The sky is no longer the limit — it's just the beginning.`,
  },
  {
    title: "The Atomic Age",
    year: 1969,
    content: `Houston, Tranquility Base here. The Eagle has landed.

I stood in Mission Control today, watching grainy television footage as Armstrong descended that ladder. The room erupted in cheers. Men wept openly. They had touched another world.

What struck me most was not the achievement itself — I had, after all, already visited their future. It was the unified purpose, the collective dream that brought them here. A quarter million people working as one, spending fortunes, risking lives, all to plant a flag on a barren rock.

Hope, I realized, is humanity's most powerful engine. More potent than steam, more revolutionary than electricity. As long as we dream of distant shores, no future is impossible.`,
  },
  {
    title: "The Internet's Birth",
    year: 1991,
    content: `CERN, Switzerland. A British scientist named Tim Berners-Lee has just published the first website. It looks impossibly simple — plain text, basic formatting, a few links.

"I call it the World Wide Web," he explains. "Anyone can publish. Anyone can access. Information wants to be free."

I've seen the future this invention creates. In thirty years, more humans will carry the entirety of human knowledge in their pockets than have ever lived. They will connect instantly across continents. They will topple governments and build communities without ever meeting in person.

The printing press freed knowledge from monasteries. The Web will free it from everything — geography, gatekeepers, even time itself.`,
  },
  {
    title: "Digital Dawn",
    year: 2024,
    content: `The children today carry more computing power in their pockets than filled entire buildings in my time. They speak to invisible assistants, visit distant lands through glowing screens, and share thoughts instantly across the globe.

Yet I see the same human struggles. Love and loneliness. Purpose and meaning. The eternal questions that no technology can answer.

I met a programmer named Sarah. She builds artificial minds — programs that learn and adapt. "Are we creating life?" she asked me over coffee.

"Perhaps," I told her. "But remember that you are already the greatest miracle. Consciousness that contemplates itself. Clay that became aware. Focus not on building new minds, but on understanding the one you already possess."`,
  },
  {
    title: "The Climate Turning",
    year: 2050,
    content: `Venice is underwater. Not temporarily flooded — permanently. The canals have reclaimed the city, turning palaces into artificial reefs. Yet amidst the loss, I see remarkable adaptation.

Floating gardens produce food. Underwater habitats house millions. Solar panels cover every surface. Fusion reactors power carbon capture machines that scrub centuries of excess from the atmosphere.

A young climate engineer named Aisha showed me the restored coral reefs. "We broke it," she said simply. "Now we're learning to fix it. Not back to what it was — forward to what it could be."

The crisis forced humanity to innovate or perish. They chose innovation. Sometimes destruction precedes rebirth.`,
  },
  {
    title: "The Merge",
    year: 2075,
    content: `The boundary between human and machine has become beautifully blurred. I met a musician today who composes symphonies with thoughts alone, her neural implant translating intention directly to sound.

A painter with augmented eyes sees colors beyond human spectrum. A dancer with enhanced joints moves with impossible grace. A teacher with memory implants carries the knowledge of a thousand professors.

"Are you still human?" I asked the musician.

She smiled. "Am I less human because I see with glasses? Hear with aids? Live with a pacemaker? Technology has always been part of us. We just stopped pretending it was separate."

Perhaps she's right. Humanity has always been a work in progress, never a finished product.`,
  },
  {
    title: "Tomorrow's Edge",
    year: 2100,
    content: `The city floats. Glass spires pierce the clouds while gardens cascade downward in vertical forests. The air smells of rain and electricity.

Humans here have merged with their machines — not violently, but gracefully. Augmented eyes that see spectrums unknown to natural biology. Neural implants that let minds touch across distances. Bodies that no longer age, at least not in the ways my generation understood.

Yet I recognize them still. They laugh. They dance. They create art that moves me to tears. They argue about politics, fall in love, dream of places they've never seen.

The technology changes. The dreams endure.

I think I finally understand my purpose here. Not to warn about dark futures or celebrate bright ones, but simply to witness. To testify that we persist. That humanity, in all its glorious stubborn beauty, continues to reach for stars.`,
  },
];

export default function LogbookReader() {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(0);
  const [currentYear, setCurrentYear] = useState(1885);

  // Sync year with page
  useEffect(() => {
    setCurrentYear(JOURNAL_PAGES[currentPage].year);
  }, [currentPage]);

  // Handle year change from timeline
  const handleYearChange = (year: number) => {
    setCurrentYear(year);
    // Find closest page to the selected year
    const closestPage = JOURNAL_PAGES.reduce((prev, curr, idx) => {
      const prevDiff = Math.abs(JOURNAL_PAGES[prev].year - year);
      const currDiff = Math.abs(curr.year - year);
      return currDiff < prevDiff ? idx : prev;
    }, 0);
    setCurrentPage(closestPage);
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" && currentPage > 0) {
        setCurrentPage(currentPage - 1);
      } else if (e.key === "ArrowRight" && currentPage < JOURNAL_PAGES.length - 1) {
        setCurrentPage(currentPage + 1);
      } else if (e.key === "Escape") {
        navigate("/", { state: { fromPage: true } });
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentPage, navigate]);

  return (
    <div className="min-h-screen pb-24 sm:pb-32 pt-6 sm:pt-8 px-3 sm:px-4 bg-background">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="max-w-7xl mx-auto mb-8"
      >
        <Button
          variant="ghost"
          onClick={() => navigate("/", { state: { fromPage: true } })}
          className="mb-4 hover:bg-primary/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Return to Study
        </Button>

        <div className="text-center px-2">
          <motion.h1 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-3xl sm:text-4xl md:text-5xl font-journal text-foreground mb-2 luxury-glow"
          >
            The Logbook
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-sm sm:text-base text-muted-foreground font-serif italic"
          >
            Chronicles of a Time Traveller
          </motion.p>
        </div>
      </motion.div>

      {/* Page Viewer */}
      <PageFlip
        pages={JOURNAL_PAGES}
        currentPage={currentPage}
        onPageChange={setCurrentPage}
      />

      {/* Timeline Ribbon */}
      <TimelineRibbon
        currentYear={currentYear}
        onYearChange={handleYearChange}
      />
    </div>
  );
}
