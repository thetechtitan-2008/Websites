import { useNavigate } from "react-router-dom";
import { ArrowLeft, Scroll, Heart, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

// Sample shared logs
const SHARED_LOGS = [
  {
    id: 1,
    author: "Eleanor R.",
    era: "Renaissance",
    year: 1505,
    title: "A Conversation with Leonardo",
    excerpt: "Today I met the great Leonardo in his workshop. His curiosity knows no bounds...",
    reactions: 47,
    comments: 12,
  },
  {
    id: 2,
    author: "Marcus T.",
    era: "Ancient",
    year: -44,
    title: "The Ides of March",
    excerpt: "I tried to warn Caesar. He wouldn't listen. History, it seems, is written in stone...",
    reactions: 89,
    comments: 23,
  },
  {
    id: 3,
    author: "Sarah K.",
    era: "Future",
    year: 2089,
    title: "First Day on Mars",
    excerpt: "The red dust gets everywhere. But standing here, looking at Earth as a blue dot...",
    reactions: 156,
    comments: 45,
  },
  {
    id: 4,
    author: "James W.",
    era: "Industrial",
    year: 1879,
    title: "Edison's Light",
    excerpt: "Witnessed the first successful test of the electric light. The world will never be dark again...",
    reactions: 73,
    comments: 18,
  },
];

export default function SharedLogs() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen py-8 sm:py-12 px-3 sm:px-4 bg-background">
      <div className="max-w-4xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate("/", { state: { fromPage: true } })}
          className="mb-8 hover:bg-primary/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Return to Study
        </Button>

        <div className="text-center mb-8 sm:mb-12 px-2">
          <h1 className="text-3xl sm:text-4xl md:text-6xl font-journal text-primary mb-3 sm:mb-4 luxury-glow">
            Shared Logs
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground font-serif italic">
            Community chronicles from across time
          </p>
        </div>

        {/* Coming Soon Notice */}
        <Card className="border-2 border-accent/30 bg-gradient-to-br from-card to-accent/5 mb-8">
          <CardContent className="p-8 text-center">
            <Scroll className="w-16 h-16 text-accent mx-auto mb-4" />
            <h3 className="text-2xl font-journal text-foreground mb-3">
              The Archive Grows
            </h3>
            <p className="text-muted-foreground font-serif mb-4">
              Soon, time travelers from around the world will share their chronicles here. 
              Each entry a window into another era, another life, another perspective.
            </p>
            <p className="text-sm text-muted-foreground font-serif italic">
              The ink is still drying on the first entries...
            </p>
          </CardContent>
        </Card>

        {/* Preview of Shared Logs */}
        <div className="space-y-6">
          <h2 className="text-2xl font-journal text-foreground mb-6">
            Featured Chronicles
          </h2>

          {SHARED_LOGS.map((log) => (
            <Card
              key={log.id}
              className="group hover:border-primary/30 transition-all cursor-pointer hover:shadow-lifted"
            >
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="font-journal text-primary">
                        {log.author[0]}
                      </span>
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{log.author}</p>
                      <p className="text-xs text-muted-foreground font-serif">
                        Visited {log.era}, Year {log.year > 0 ? log.year : `${Math.abs(log.year)} BCE`}
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline" className="font-serif">
                    {log.era}
                  </Badge>
                </div>
                
                <CardTitle className="text-xl font-journal group-hover:text-primary transition-colors">
                  {log.title}
                </CardTitle>
                
                <CardDescription className="font-serif">
                  {log.excerpt}
                </CardDescription>
              </CardHeader>

              <CardContent>
                <div className="flex items-center gap-6 text-sm text-muted-foreground">
                  <button className="flex items-center gap-2 hover:text-destructive transition-colors seal-press">
                    <Heart className="w-4 h-4" />
                    <span>{log.reactions}</span>
                  </button>
                  <button className="flex items-center gap-2 hover:text-primary transition-colors">
                    <MessageCircle className="w-4 h-4" />
                    <span>{log.comments}</span>
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
