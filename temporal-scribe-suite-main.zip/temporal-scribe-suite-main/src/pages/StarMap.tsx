import { useNavigate } from "react-router-dom";
import { ArrowLeft, Telescope, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function StarMap() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen py-8 sm:py-12 px-3 sm:px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate("/", { state: { fromPage: true } })}
          className="mb-8 hover:bg-primary/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Return to Study
        </Button>

        <div className="text-center mb-8 sm:mb-12 px-2">
          <h1 className="text-3xl sm:text-4xl md:text-6xl font-journal text-primary mb-3 sm:mb-4 luxury-glow">
            Time Machine
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground font-serif italic">
            Peer beyond the stars
          </p>
        </div>

        {/* Placeholder for 3D star map */}
        <Card className="border-2 border-primary/30 bg-gradient-to-b from-card to-card/50">
          <CardContent className="p-12 text-center space-y-6">
            <div className="flex justify-center mb-8">
              <div className="relative">
                <Telescope className="w-32 h-32 text-primary/30" />
                <Star className="absolute -top-4 -right-4 w-12 h-12 text-accent animate-pulse" />
              </div>
            </div>

            <h2 className="text-3xl font-journal text-foreground">
              The Star Map Awaits
            </h2>
            
            <p className="text-lg text-muted-foreground font-serif max-w-2xl mx-auto">
              Soon, you'll navigate a 3D constellation of events across time. 
              Each star represents a moment in history, waiting to be explored. 
              The machinery is being calibrated...
            </p>

            <div className="flex flex-wrap justify-center gap-4 pt-8">
              <Button
                variant="outline"
                onClick={() => navigate("/logbook")}
                className="hover:bg-primary hover:text-primary-foreground"
              >
                Explore the Logbook Instead
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate("/era-explorer")}
                className="hover:bg-primary hover:text-primary-foreground"
              >
                Browse Eras
              </Button>
            </div>

            <p className="text-sm text-muted-foreground font-serif italic pt-4">
              "Any sufficiently advanced technology is indistinguishable from magic."
              <br />
              — Arthur C. Clarke
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
