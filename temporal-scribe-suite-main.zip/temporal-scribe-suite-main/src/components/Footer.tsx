import { motion } from "framer-motion";

const Footer = () => {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.4 }}
      className="py-8 px-4 mt-24 relative"
    >
      {/* Grand entrance light beam */}
      <motion.div
        initial={{ scaleY: 0, opacity: 0 }}
        whileInView={{ scaleY: 1, opacity: 0.4 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
        className="absolute inset-x-0 top-0 h-full mx-auto w-1 origin-top"
        style={{
          background: "linear-gradient(180deg, transparent, hsl(var(--brass-shine)), transparent)",
          filter: "blur(30px)"
        }}
      />

      <motion.div
        initial={{ scale: 0.8, opacity: 0, rotateX: 45 }}
        whileInView={{ scale: 1, opacity: 1, rotateX: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ 
          duration: 1.2, 
          ease: [0.22, 1, 0.36, 1],
          delay: 0.2
        }}
        className="max-w-2xl mx-auto text-center p-8 md:p-12 rounded-2xl relative overflow-hidden perspective-lg"
        style={{
          background: "linear-gradient(135deg, hsl(var(--card) / 0.95) 0%, hsl(var(--card) / 0.85) 100%)",
          border: "2px solid hsl(var(--brass-shine) / 0.4)",
          boxShadow: "0 0 40px hsl(var(--brass-shine) / 0.2), inset 0 0 60px hsl(var(--brass-shine) / 0.05)",
          transformStyle: "preserve-3d"
        }}
        whileHover={{
          scale: 1.02,
          rotateY: 2,
          transition: { duration: 0.4 }
        }}
      >
        {/* Expanding ring animation on entrance */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          whileInView={{ scale: 3, opacity: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 1.5, ease: "easeOut", delay: 0.3 }}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div 
            className="w-32 h-32 rounded-full border-2"
            style={{ 
              borderColor: "hsl(var(--brass-shine) / 0.6)",
              boxShadow: "0 0 40px hsl(var(--brass-shine) / 0.5)"
            }}
          />
        </motion.div>

        {/* Rotating Chakra - Top Left */}
        <motion.div
          initial={{ scale: 0, rotate: -180, opacity: 0 }}
          whileInView={{ scale: 1, rotate: 0, opacity: 0.4 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 1, ease: [0.34, 1.56, 0.64, 1], delay: 0.5 }}
          animate={{ 
            rotate: 360,
            scale: [1, 1.1, 1]
          }}
          className="absolute -top-8 -left-8 w-24 h-24"
          style={{
            filter: "drop-shadow(0 0 20px hsl(var(--brass-shine) / 0.6))"
          }}
        >
          <motion.svg 
            viewBox="0 0 100 100" 
            className="w-full h-full"
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--brass-shine))" strokeWidth="2" opacity="0.3"/>
            <circle cx="50" cy="50" r="35" fill="none" stroke="hsl(var(--brass-shine))" strokeWidth="1.5" opacity="0.4"/>
            <circle cx="50" cy="50" r="25" fill="none" stroke="hsl(var(--brass-shine))" strokeWidth="1" opacity="0.5"/>
            {[...Array(8)].map((_, i) => (
              <g key={i} transform={`rotate(${i * 45} 50 50)`}>
                <line x1="50" y1="5" x2="50" y2="20" stroke="hsl(var(--brass-shine))" strokeWidth="2" opacity="0.6"/>
                <circle cx="50" cy="12" r="3" fill="hsl(var(--brass-shine))" opacity="0.7"/>
                <path d="M 50 25 Q 55 35 50 45 Q 45 35 50 25" fill="hsl(var(--brass-shine))" opacity="0.5"/>
              </g>
            ))}
            <circle cx="50" cy="50" r="8" fill="hsl(var(--brass-shine))" opacity="0.8"/>
          </motion.svg>
        </motion.div>

        {/* Rotating Chakra - Top Right */}
        <motion.div
          initial={{ scale: 0, rotate: 180, opacity: 0 }}
          whileInView={{ scale: 1, rotate: 0, opacity: 0.3 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 1, ease: [0.34, 1.56, 0.64, 1], delay: 0.6 }}
          animate={{ 
            rotate: -360,
            scale: [1, 1.15, 1]
          }}
          className="absolute -top-6 -right-6 w-20 h-20"
          style={{
            filter: "drop-shadow(0 0 15px hsl(var(--brass-shine) / 0.5))"
          }}
        >
          <motion.svg 
            viewBox="0 0 100 100" 
            className="w-full h-full"
            initial={{ rotate: 0 }}
            animate={{ rotate: -360 }}
            transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          >
            <circle cx="50" cy="50" r="40" fill="none" stroke="hsl(var(--brass-shine))" strokeWidth="1.5" opacity="0.4"/>
            {[...Array(6)].map((_, i) => (
              <g key={i} transform={`rotate(${i * 60} 50 50)`}>
                <line x1="50" y1="10" x2="50" y2="25" stroke="hsl(var(--brass-shine))" strokeWidth="1.5" opacity="0.6"/>
                <circle cx="50" cy="17" r="2.5" fill="hsl(var(--brass-shine))" opacity="0.7"/>
              </g>
            ))}
          </motion.svg>
        </motion.div>

        {/* Rotating Chakra - Bottom Left */}
        <motion.div
          initial={{ scale: 0, rotate: -180, opacity: 0 }}
          whileInView={{ scale: 1, rotate: 0, opacity: 0.35 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 1, ease: [0.34, 1.56, 0.64, 1], delay: 0.7 }}
          animate={{ 
            rotate: 360,
            scale: [1, 1.2, 1]
          }}
          className="absolute -bottom-6 -left-6 w-20 h-20"
          style={{
            filter: "drop-shadow(0 0 18px hsl(var(--brass-shine) / 0.5))"
          }}
        >
          <motion.svg 
            viewBox="0 0 100 100" 
            className="w-full h-full"
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          >
            <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--brass-shine))" strokeWidth="1.5" opacity="0.3"/>
            {[...Array(12)].map((_, i) => (
              <line key={i} x1="50" y1="50" x2="50" y2="8" stroke="hsl(var(--brass-shine))" strokeWidth="1" opacity="0.4" transform={`rotate(${i * 30} 50 50)`}/>
            ))}
          </motion.svg>
        </motion.div>

        {/* Rotating Chakra - Bottom Right */}
        <motion.div
          initial={{ scale: 0, rotate: 180, opacity: 0 }}
          whileInView={{ scale: 1, rotate: 0, opacity: 0.4 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 1, ease: [0.34, 1.56, 0.64, 1], delay: 0.8 }}
          animate={{ 
            rotate: -360,
            scale: [1, 1.1, 1]
          }}
          className="absolute -bottom-8 -right-8 w-24 h-24"
          style={{
            filter: "drop-shadow(0 0 20px hsl(var(--brass-shine) / 0.6))"
          }}
        >
          <motion.svg 
            viewBox="0 0 100 100" 
            className="w-full h-full"
            initial={{ rotate: 0 }}
            animate={{ rotate: -360 }}
            transition={{ duration: 22, repeat: Infinity, ease: "linear" }}
          >
            <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--brass-shine))" strokeWidth="2" opacity="0.3"/>
            {[...Array(8)].map((_, i) => (
              <g key={i} transform={`rotate(${i * 45} 50 50)`}>
                <line x1="50" y1="5" x2="50" y2="20" stroke="hsl(var(--brass-shine))" strokeWidth="2" opacity="0.6"/>
                <circle cx="50" cy="12" r="3" fill="hsl(var(--brass-shine))" opacity="0.7"/>
              </g>
            ))}
            <circle cx="50" cy="50" r="8" fill="hsl(var(--brass-shine))" opacity="0.8"/>
          </motion.svg>
        </motion.div>

        {/* Center Rotating Chakra with entrance */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          whileInView={{ scale: 1, opacity: 0.2 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 1.5, ease: "easeOut", delay: 0.4 }}
          animate={{ 
            rotate: 360,
            opacity: [0.1, 0.2, 0.1]
          }}
          className="absolute inset-0 flex items-center justify-center"
          style={{
            filter: "blur(1px)"
          }}
        >
          <motion.svg 
            viewBox="0 0 200 200" 
            className="w-full h-full"
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          >
            <circle cx="100" cy="100" r="90" fill="none" stroke="hsl(var(--brass-shine))" strokeWidth="1" opacity="0.2"/>
            <circle cx="100" cy="100" r="70" fill="none" stroke="hsl(var(--brass-shine))" strokeWidth="0.5" opacity="0.3"/>
            <circle cx="100" cy="100" r="50" fill="none" stroke="hsl(var(--brass-shine))" strokeWidth="0.5" opacity="0.4"/>
            {[...Array(16)].map((_, i) => (
              <line key={i} x1="100" y1="100" x2="100" y2="10" stroke="hsl(var(--brass-shine))" strokeWidth="0.5" opacity="0.2" transform={`rotate(${i * 22.5} 100 100)`}/>
            ))}
          </motion.svg>
        </motion.div>

        {/* Shimmer particles with staggered entrance */}
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5, delay: 0.6 + (i * 0.05) }}
            className="absolute w-1 h-1 rounded-full"
            style={{
              background: "hsl(var(--brass-shine))",
              left: `${20 + (i * 5)}%`,
              top: `${30 + (i % 3) * 20}%`,
            }}
            animate={{
              opacity: [0, 0.8, 0],
              scale: [0, 1.5, 0],
              y: [-20, 0, 20]
            }}
          />
        ))}

        {/* Decorative corner accents with draw-in animation */}
        <motion.div 
          initial={{ pathLength: 0, opacity: 0 }}
          whileInView={{ pathLength: 1, opacity: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="absolute top-0 left-0 w-16 h-16"
        >
          <svg className="w-full h-full" viewBox="0 0 64 64">
            <motion.path
              d="M 0 16 Q 0 0 16 0 L 64 0"
              fill="none"
              stroke="hsl(var(--brass-shine))"
              strokeWidth="2"
              opacity="0.5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.9 }}
            />
            <motion.path
              d="M 16 0 Q 0 0 0 16 L 0 64"
              fill="none"
              stroke="hsl(var(--brass-shine))"
              strokeWidth="2"
              opacity="0.5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 1 }}
            />
          </svg>
        </motion.div>

        <motion.div 
          initial={{ pathLength: 0, opacity: 0 }}
          whileInView={{ pathLength: 1, opacity: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="absolute top-0 right-0 w-16 h-16"
        >
          <svg className="w-full h-full" viewBox="0 0 64 64">
            <motion.path
              d="M 64 16 Q 64 0 48 0 L 0 0"
              fill="none"
              stroke="hsl(var(--brass-shine))"
              strokeWidth="2"
              opacity="0.5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 1 }}
            />
            <motion.path
              d="M 48 0 Q 64 0 64 16 L 64 64"
              fill="none"
              stroke="hsl(var(--brass-shine))"
              strokeWidth="2"
              opacity="0.5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 1.1 }}
            />
          </svg>
        </motion.div>

        <motion.div 
          initial={{ pathLength: 0, opacity: 0 }}
          whileInView={{ pathLength: 1, opacity: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, delay: 1.1 }}
          className="absolute bottom-0 left-0 w-16 h-16"
        >
          <svg className="w-full h-full" viewBox="0 0 64 64">
            <motion.path
              d="M 0 48 Q 0 64 16 64 L 64 64"
              fill="none"
              stroke="hsl(var(--brass-shine))"
              strokeWidth="2"
              opacity="0.5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 1.1 }}
            />
            <motion.path
              d="M 16 64 Q 0 64 0 48 L 0 0"
              fill="none"
              stroke="hsl(var(--brass-shine))"
              strokeWidth="2"
              opacity="0.5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 1.2 }}
            />
          </svg>
        </motion.div>

        <motion.div 
          initial={{ pathLength: 0, opacity: 0 }}
          whileInView={{ pathLength: 1, opacity: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, delay: 1.2 }}
          className="absolute bottom-0 right-0 w-16 h-16"
        >
          <svg className="w-full h-full" viewBox="0 0 64 64">
            <motion.path
              d="M 64 48 Q 64 64 48 64 L 0 64"
              fill="none"
              stroke="hsl(var(--brass-shine))"
              strokeWidth="2"
              opacity="0.5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 1.2 }}
            />
            <motion.path
              d="M 48 64 Q 64 64 64 48 L 64 0"
              fill="none"
              stroke="hsl(var(--brass-shine))"
              strokeWidth="2"
              opacity="0.5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 1.3 }}
            />
          </svg>
        </motion.div>

        {/* Content with elegant staggered entrance */}
        <div className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.9 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.5 }}
            animate={{ 
              textShadow: [
                "0 0 20px hsl(var(--brass-shine) / 0.3)",
                "0 0 30px hsl(var(--brass-shine) / 0.5)",
                "0 0 20px hsl(var(--brass-shine) / 0.3)"
              ]
            }}
          >
            <h3 className="font-journal text-3xl md:text-4xl text-primary mb-3 tracking-wide">
              The Logbook of Abhiram R Ajay
            </h3>
          </motion.div>
          
          <motion.div 
            initial={{ scaleX: 0, opacity: 0 }}
            whileInView={{ scaleX: 1, opacity: 1 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.7 }}
            className="w-32 h-0.5 mx-auto mb-3"
            style={{
              background: "linear-gradient(90deg, transparent, hsl(var(--brass-shine)), transparent)"
            }}
            animate={{
              scaleX: [1, 1.5, 1],
              opacity: [0.5, 1, 0.5]
            }}
          />
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="text-muted-foreground font-serif text-base md:text-lg italic"
          >
            @hooked_tin_29
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6, delay: 1.1 }}
            className="mt-4 text-xs font-serif text-muted-foreground/70"
            animate={{ opacity: [0.5, 0.8, 0.5] }}
          >
            ✦ A Chronicle Through Time ✦
          </motion.div>
        </div>
      </motion.div>
    </motion.footer>
  );
};

export default Footer;
