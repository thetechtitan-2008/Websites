import { Button } from "@/components/ui/button";
import { useNavigate, useLocation } from "react-router-dom";
import studyDeskHero from "@/assets/study-desk-hero.jpg";
import logbookCover from "@/assets/logbook-cover.jpg";
import telescope from "@/assets/telescope.png";
import hourglass from "@/assets/hourglass.png";
import worldMap from "@/assets/world-map.png";
import scroll from "@/assets/scroll.png";
import { BookOpen, Telescope, Clock, Map, ScrollText, ChevronDown } from "lucide-react";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";
import { useState, useEffect, useCallback, memo } from "react";
import Footer from "@/components/Footer";

const StudyDesk = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
  
  const [showIntro, setShowIntro] = useState(() => {
    return !location.state?.fromPage;
  });
  
  const { scrollYProgress } = useScroll();
  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", isMobile ? "10%" : "30%"]);
  
  useEffect(() => {
    if (showIntro) {
      // Show intro animation
      window.scrollTo(0, 0);
      const timer = setTimeout(() => {
        setShowIntro(false);
      }, 1600);
      return () => clearTimeout(timer);
    } else if (location.state?.fromPage) {
      // If returning from another page, scroll to study section
      const studySection = document.getElementById('study-section');
      if (studySection) {
        studySection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  }, [showIntro, location.state]);

  const deskObjects = [
    {
      id: "logbook",
      title: "Open the Logbook",
      description: "Enter the Journey",
      image: logbookCover,
      icon: BookOpen,
      path: "/logbook",
    },
    {
      id: "telescope",
      title: "Time Machine",
      description: "Peer beyond the stars",
      image: telescope,
      icon: Telescope,
      path: "/star-map",
    },
    {
      id: "hourglass",
      title: "Time Capsule",
      description: "Seal a Memory",
      image: hourglass,
      icon: Clock,
      path: "/time-capsule",
    },
    {
      id: "map",
      title: "Era Explorer",
      description: "Navigate the centuries",
      image: worldMap,
      icon: Map,
      path: "/era-explorer",
    },
    {
      id: "scroll",
      title: "Shared Logs",
      description: "Community chronicles",
      image: scroll,
      icon: ScrollText,
      path: "/shared-logs",
    },
  ];

  const handleObjectClick = useCallback((path: string) => {
    navigate(path, { state: { fromPage: 'studyDesk' } });
  }, [navigate]);

  return (
    <>
      <AnimatePresence>
        {showIntro && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, delay: 1.2 }}
            className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden gpu-accelerate"
            style={{
              background: "radial-gradient(circle at center, #1a0f0a 0%, #0a0604 50%, #000000 100%)",
              willChange: "opacity"
            }}
          >
            {/* Golden Chakra/Clock Background */}
            <motion.div
              initial={{ opacity: 0, scale: 0, rotate: 0 }}
              animate={{ 
                opacity: [0, 0.4, 0.4, 0],
                scale: [0, 1.5, 1.5, 2],
                rotate: [0, 360, 720, 1440]
              }}
              transition={{ 
                duration: 1.7,
                times: [0, 0.15, 0.85, 1],
                ease: "linear"
              }}
              className="absolute inset-0 flex items-center justify-center gpu-layer"
            >
              <svg width="400" height="400" viewBox="0 0 400 400" className="w-[80vw] h-[80vw] max-w-[400px] max-h-[400px]">
                <circle cx="200" cy="200" r="180" fill="none" stroke="rgba(176, 125, 59, 0.6)" strokeWidth="2" />
                <circle cx="200" cy="200" r="150" fill="none" stroke="rgba(255, 215, 0, 0.4)" strokeWidth="1" />
                <circle cx="200" cy="200" r="120" fill="none" stroke="rgba(176, 125, 59, 0.5)" strokeWidth="2" />
                {[...Array(12)].map((_, i) => (
                  <line
                    key={i}
                    x1="200"
                    y1="30"
                    x2="200"
                    y2="50"
                    stroke="rgba(176, 125, 59, 0.8)"
                    strokeWidth="3"
                    transform={`rotate(${i * 30} 200 200)`}
                  />
                ))}
                {[...Array(8)].map((_, i) => (
                  <path
                    key={`petal-${i}`}
                    d="M 200 200 Q 200 140 200 100 Q 200 140 200 200"
                    fill="rgba(176, 125, 59, 0.3)"
                    stroke="rgba(255, 215, 0, 0.6)"
                    strokeWidth="1"
                    transform={`rotate(${i * 45} 200 200)`}
                  />
                ))}
              </svg>
            </motion.div>

            {/* Multiple layers of animated golden particles - optimized */}
            <div className="absolute inset-0 gpu-layer optimize-animations">
              {[...Array(typeof window !== 'undefined' && window.innerWidth < 768 ? 15 : 30)].map((_, i) => (
                <motion.div
                  key={`particle-${i}`}
                  initial={{ opacity: 0, scale: 0, x: "50vw", y: "50vh" }}
                  animate={{ 
                    opacity: [0, 1, 1, 0],
                    scale: [0, Math.random() * 2 + 0.5, Math.random() * 1.5 + 0.5, 0],
                    x: [0, (Math.random() - 0.5) * window.innerWidth * 1.5],
                    y: [0, (Math.random() - 0.5) * window.innerHeight * 1.5],
                    rotate: [0, Math.random() * 720]
                  }}
                  transition={{
                    duration: 1.5,
                    times: [0, 0.3, 0.8, 1],
                    delay: Math.random() * 0.3,
                    ease: [0.25, 0.1, 0.25, 1]
                  }}
                  className="absolute w-3 h-3 rounded-full gpu-layer"
                  style={{
                    left: "50%",
                    top: "50%",
                    background: `radial-gradient(circle, rgba(176, 125, 59, ${Math.random() * 0.5 + 0.5}), rgba(255, 215, 0, ${Math.random() * 0.3 + 0.3}))`,
                    boxShadow: `0 0 ${Math.random() * 20 + 10}px ${Math.random() * 10 + 5}px rgba(176, 125, 59, 0.8)`,
                  }}
                />
              ))}
            </div>

            {/* Rotating golden rings */}
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={`ring-${i}`}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ 
                  opacity: [0, 0.6, 0.6, 0],
                  scale: [0, 1.5 + i * 0.3, 1.5 + i * 0.3, 2 + i * 0.5],
                  rotate: [0, 180, 360, 540]
                }}
                transition={{
                  duration: 1.5,
                  times: [0, 0.3, 0.7, 1],
                  delay: i * 0.06,
                  ease: [0.42, 0, 0.58, 1]
                }}
                className="absolute w-64 h-64 border-2 rounded-full gpu-layer"
                style={{
                  borderColor: `rgba(176, 125, 59, ${0.8 - i * 0.15})`,
                  boxShadow: `0 0 30px rgba(176, 125, 59, ${0.6 - i * 0.1}), inset 0 0 30px rgba(176, 125, 59, ${0.4 - i * 0.08})`
                }}
              />
            ))}

            {/* Central starburst */}
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={{ 
                opacity: [0, 1, 1, 0],
                scale: [0, 1, 1.2, 3],
                rotate: [0, 180, 360, 540]
              }}
              transition={{ duration: 1.5, times: [0, 0.2, 0.7, 1], ease: [0.33, 1, 0.68, 1] }}
              className="absolute gpu-layer"
            >
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={`ray-${i}`}
                  className="absolute w-1 h-32 bg-gradient-to-t from-brass-shine via-brass-shine/50 to-transparent gpu-layer"
                  style={{
                    left: "50%",
                    top: "50%",
                    transformOrigin: "center bottom",
                    transform: `rotate(${i * 30}deg)`,
                    boxShadow: "0 0 20px 2px rgba(176, 125, 59, 0.8)"
                  }}
                  animate={{
                    scaleY: [0, 1.5, 1, 0],
                    opacity: [0, 1, 0.8, 0]
                  }}
                  transition={{
                    duration: 1.5,
                    times: [0, 0.3, 0.7, 1],
                    delay: i * 0.03,
                    ease: [0.33, 1, 0.68, 1]
                  }}
                />
              ))}
            </motion.div>

            {/* Main title with letter animation */}
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: [0, 1, 1, 0.8], scale: [0.5, 1.2, 1, 1] }}
              transition={{ 
                duration: 1.5,
                times: [0, 0.4, 0.6, 1],
                ease: [0.34, 1.56, 0.64, 1]
              }}
              className="relative z-10 gpu-accelerate"
            >
              <motion.h1 
                className="font-journal text-3xl sm:text-4xl md:text-6xl lg:text-7xl text-brass-shine text-center px-4"
                style={{
                  textShadow: "0 0 20px rgba(176, 125, 59, 1), 0 0 40px rgba(255, 215, 0, 0.8), 0 0 60px rgba(176, 125, 59, 0.6), 0 0 80px rgba(255, 215, 0, 0.4), 0 0 100px rgba(176, 125, 59, 0.3)",
                  background: "linear-gradient(90deg, #b07d3b 0%, #ffd700 25%, #b07d3b 50%, #ffd700 75%, #b07d3b 100%)",
                  backgroundSize: "200% auto",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
                animate={{
                  backgroundPosition: ["0% center", "200% center"],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "linear"
                }}
              >
                {"The Time Traveller's Logbook".split("").map((char, i) => (
                  <motion.span
                    key={i}
                    initial={{ opacity: 0, y: 50, rotateX: -90 }}
                    animate={{ opacity: 1, y: 0, rotateX: 0 }}
                    transition={{
                      duration: 0.3,
                      delay: 0.2 + i * 0.02,
                      ease: [0.34, 1.56, 0.64, 1]
                    }}
                    style={{ display: "inline-block" }}
                  >
                    {char === " " ? "\u00A0" : char}
                  </motion.span>
                ))}
              </motion.h1>
              
              {/* Multiple glowing halos */}
              {[...Array(3)].map((_, i) => (
                <motion.div
                  key={`halo-${i}`}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ 
                    opacity: [0, 0.6, 0.4, 0],
                    scale: [0, 2 + i, 3 + i, 5 + i]
                  }}
                  transition={{ 
                    duration: 1.5,
                    times: [0, 0.3, 0.7, 1],
                    delay: i * 0.12,
                    ease: [0.33, 1, 0.68, 1]
                  }}
                  className="absolute inset-0 rounded-full blur-3xl gpu-layer"
                  style={{
                    background: `radial-gradient(circle, rgba(176, 125, 59, ${0.6 - i * 0.15}) 0%, rgba(255, 215, 0, ${0.4 - i * 0.1}) 30%, transparent 70%)`
                  }}
                />
              ))}
            </motion.div>

            {/* Golden sparkles - optimized */}
            {[...Array(typeof window !== 'undefined' && window.innerWidth < 768 ? 8 : 15)].map((_, i) => (
              <motion.div
                key={`sparkle-${i}`}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ 
                  opacity: [0, 1, 0],
                  scale: [0, 1.5, 0],
                }}
                transition={{
                  duration: 1.5,
                  delay: Math.random() * 2,
                  repeat: Infinity,
                  repeatDelay: Math.random() * 2
                }}
                className="absolute w-2 h-2 gpu-layer"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  background: "radial-gradient(circle, #ffd700, transparent)",
                  boxShadow: "0 0 10px 2px rgba(255, 215, 0, 0.8)"
                }}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="min-h-screen cursor-trail">
        {/* Hero Section */}
        <motion.section 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.6 }}
          className="relative h-screen flex items-center justify-center overflow-hidden gpu-accelerate"
        >
          <motion.div 
            style={{ y: backgroundY }}
            className="absolute inset-0 z-0 gpu-layer"
          >
            <img 
              src={studyDeskHero} 
              alt="Vintage study desk" 
              className="w-full h-full object-cover md:opacity-30 opacity-50"
              loading="eager"
              decoding="async"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background" />
            <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-b from-transparent to-background/80 md:hidden" />
          </motion.div>
          
          <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 1.8, ease: "easeOut" }}
              className="relative"
            >
              {/* Elegant ornate frame */}
              <div className="absolute -inset-10 md:-inset-12 border border-brass-shine/40 rounded-2xl backdrop-blur-sm" 
                style={{
                  background: "radial-gradient(circle at center, rgba(176, 125, 59, 0.15), transparent 65%)",
                  boxShadow: "inset 0 0 60px rgba(176, 125, 59, 0.1)"
                }}
              />
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 80, repeat: Infinity, ease: "linear" }}
                className="absolute -inset-16 border border-brass-shine/25 rounded-full opacity-60"
              />
              
              <motion.h1 
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 2.0, ease: "easeOut" }}
                className="font-journal text-5xl md:text-7xl lg:text-9xl mb-8 text-primary relative z-10"
                style={{
                  textShadow: "0 0 40px hsl(var(--brass-shine) / 0.5), 0 0 80px hsl(var(--brass-shine) / 0.3)",
                  letterSpacing: "0.02em"
                }}
              >
                The Time Traveller's Logbook
              </motion.h1>
            </motion.div>
            
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 2.3 }}
              className="font-serif text-xl md:text-2xl text-muted-foreground mb-16 italic mt-16 md:mt-20 px-4"
              style={{
                textShadow: "0 2px 8px rgba(0,0,0,0.8), 0 4px 16px rgba(0,0,0,0.6)"
              }}
            >
              Open a page. Live a century.
            </motion.p>
            
            <motion.div 
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              onClick={() => {
                const studySection = document.getElementById('study-section');
                if (studySection) {
                  studySection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
              }}
              className="flex justify-center mt-4 cursor-pointer"
              style={{
                filter: "drop-shadow(0 2px 8px rgba(0,0,0,0.8))"
              }}
            >
              <ChevronDown className="w-8 h-8 text-primary" />
            </motion.div>
          </div>
          
          {/* Floating particles - optimized */}
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(typeof window !== 'undefined' && window.innerWidth < 768 ? 5 : 10)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ 
                  opacity: [0, 0.6, 0],
                  y: [Math.random() * 100, -100],
                  x: [0, (Math.random() - 0.5) * 100]
                }}
                transition={{
                  duration: 3 + Math.random() * 4,
                  repeat: Infinity,
                  delay: Math.random() * 3,
                  ease: "easeOut"
                }}
                className="absolute w-1 h-1 bg-brass-shine rounded-full gpu-layer"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${50 + Math.random() * 50}%`,
                  boxShadow: "0 0 10px 2px rgba(176, 125, 59, 0.5)"
                }}
              />
            ))}
          </div>
        </motion.section>

        {/* Interactive Desk Section */}
        <motion.section 
          id="study-section"
          initial={{ opacity: 0, y: 100 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative py-24 px-4 scroll-mt-20"
        >
          {/* Animated background shimmer */}
          <motion.div
            className="absolute inset-0 opacity-20 pointer-events-none"
            animate={{
              background: [
                "radial-gradient(circle at 20% 50%, rgba(176, 125, 59, 0.3) 0%, transparent 50%)",
                "radial-gradient(circle at 80% 50%, rgba(176, 125, 59, 0.3) 0%, transparent 50%)",
                "radial-gradient(circle at 20% 50%, rgba(176, 125, 59, 0.3) 0%, transparent 50%)",
              ]
            }}
            transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          />
          <div className="max-w-7xl mx-auto">
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="font-journal text-4xl md:text-6xl text-center mb-6 text-primary relative"
              style={{
                textShadow: "0 0 40px hsl(var(--brass-shine) / 0.4), 0 0 60px hsl(var(--brass-shine) / 0.2)",
                letterSpacing: "0.03em"
              }}
            >
              Your Study Awaits
              <motion.div
                className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-32 h-1 rounded-full bg-gradient-to-r from-transparent via-brass-shine to-transparent"
                initial={{ scaleX: 0, opacity: 0 }}
                whileInView={{ scaleX: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5, duration: 0.8 }}
              />
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-center text-muted-foreground mb-20 text-lg font-serif italic"
            >
              Choose your journey through time
            </motion.p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 max-w-6xl mx-auto px-2">
              {deskObjects.map((obj, index) => (
                <motion.div
                  key={obj.id}
                  initial={{ opacity: 0, y: 80, scale: 0.8 }}
                  whileInView={{ opacity: 1, y: 0, scale: 1 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ 
                    duration: 0.8, 
                    delay: index * 0.15, 
                    ease: [0.25, 0.46, 0.45, 0.94]
                  }}
                  whileHover={{ 
                    y: -12, 
                    scale: 1.05,
                    rotateY: 5,
                    transition: { duration: 0.3, ease: "easeOut" }
                  }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleObjectClick(obj.path)}
                  className="desk-object group relative bg-gradient-to-br from-card/90 to-card/70 backdrop-blur-md rounded-xl p-8 shadow-2xl transition-all duration-500 cursor-pointer overflow-hidden border border-brass-shine/30 active:border-brass-shine/70 gpu-accelerate optimize-animations"
                  style={{
                    background: "linear-gradient(135deg, hsl(var(--card) / 0.95) 0%, hsl(var(--card) / 0.85) 100%)",
                    transformStyle: "preserve-3d",
                    perspective: "1000px",
                    backdropFilter: "blur(16px) saturate(180%)"
                  }}
                >
                  {/* Elegant glow overlay */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-brass-shine/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                    initial={false}
                  />
                  
                  <div className="relative z-10">
                    <div className="w-full h-52 mb-6 rounded-lg overflow-hidden relative shadow-lg ring-1 ring-brass-shine/20 transition-all duration-500">
                      <motion.img
                        whileHover={{ scale: 1.08 }}
                        transition={{ duration: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
                        src={obj.image}
                        alt={obj.title}
                        className="w-full h-full object-cover"
                        loading="lazy"
                        decoding="async"
                      />
                      <motion.div 
                        className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      />
                    </div>
                    
                    <div className="flex items-center gap-3 mb-3">
                      <motion.div
                        whileHover={{ rotate: 360, scale: 1.2 }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                        className="p-3 bg-primary/10 rounded-lg border border-brass-shine/30 transition-all duration-500"
                      >
                        <obj.icon className="w-6 h-6 text-primary" />
                      </motion.div>
                      <h3 className="font-journal text-xl text-foreground transition-colors duration-500">
                        {obj.title}
                      </h3>
                    </div>
                    
                    <p className="text-muted-foreground font-serif text-sm leading-relaxed">{obj.description}</p>
                  </div>
                  
                  <motion.div
                    className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-brass-shine to-primary"
                    initial={{ scaleX: 0 }}
                    whileHover={{ scaleX: 1 }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                    style={{ transformOrigin: "left" }}
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
        <Footer />
      </div>
    </>
  );
};

export default memo(StudyDesk);
