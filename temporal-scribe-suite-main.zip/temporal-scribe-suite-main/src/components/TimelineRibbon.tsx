import { useState, useRef, useEffect } from "react";
import { Milestone } from "lucide-react";

interface Era {
  year: number;
  label: string;
  color: string;
}

const ERAS: Era[] = [
  { year: -3000, label: "Ancient", color: "hsl(33, 48%, 46%)" },
  { year: 1400, label: "Renaissance", color: "hsl(33, 48%, 46%)" },
  { year: 1760, label: "Industrial", color: "hsl(33, 48%, 46%)" },
  { year: 1945, label: "Modern", color: "hsl(185, 98%, 76%)" },
  { year: 2024, label: "Present", color: "hsl(185, 98%, 76%)" },
  { year: 2100, label: "Future", color: "hsl(185, 98%, 76%)" },
];

interface TimelineRibbonProps {
  currentYear: number;
  onYearChange: (year: number) => void;
}

export const TimelineRibbon = ({ currentYear, onYearChange }: TimelineRibbonProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const ribbonRef = useRef<HTMLDivElement>(null);

  const minYear = -3000;
  const maxYear = 2100;

  // Convert year to percentage position
  const yearToPercent = (year: number) => {
    return ((year - minYear) / (maxYear - minYear)) * 100;
  };

  // Convert percentage to year
  const percentToYear = (percent: number) => {
    return Math.round(minYear + (percent / 100) * (maxYear - minYear));
  };

  const handleMouseDown = () => {
    setIsDragging(true);
  };

  const handleMouseUp = () => {
    if (isDragging) {
      // Snap to nearest era
      const nearestEra = ERAS.reduce((prev, curr) => {
        return Math.abs(curr.year - currentYear) < Math.abs(prev.year - currentYear)
          ? curr
          : prev;
      });
      onYearChange(nearestEra.year);
    }
    setIsDragging(false);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging && ribbonRef.current) {
      const rect = ribbonRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const percent = Math.max(0, Math.min(100, (x / rect.width) * 100));
      const year = percentToYear(percent);
      onYearChange(year);
    }
  };

  useEffect(() => {
    if (isDragging) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      return () => {
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };
    }
  }, [isDragging, currentYear]);

  const currentPercent = yearToPercent(currentYear);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-sm border-t border-border p-4 shadow-lifted">
      <div className="max-w-7xl mx-auto">
        {/* Current Year Display */}
        <div className="text-center mb-3">
          <span className="font-journal text-2xl text-foreground">
            {currentYear > 0 ? `${currentYear} CE` : `${Math.abs(currentYear)} BCE`}
          </span>
        </div>

        {/* Timeline Ribbon */}
        <div
          ref={ribbonRef}
          className="relative h-12 cursor-grab active:cursor-grabbing"
          onMouseDown={handleMouseDown}
          role="slider"
          aria-label="Timeline scrubber"
          aria-valuemin={minYear}
          aria-valuemax={maxYear}
          aria-valuenow={currentYear}
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "ArrowLeft") {
              onYearChange(Math.max(minYear, currentYear - 10));
            } else if (e.key === "ArrowRight") {
              onYearChange(Math.min(maxYear, currentYear + 10));
            }
          }}
        >
          {/* Thread line */}
          <div className="absolute top-1/2 left-0 right-0 h-1 -translate-y-1/2">
            {/* Background thread */}
            <div className="absolute inset-0 bg-border rounded-full" />
            
            {/* Active thread (brass glow) */}
            <div
              className="absolute left-0 top-0 bottom-0 bg-primary rounded-full transition-all duration-200"
              style={{
                width: `${currentPercent}%`,
                boxShadow: "0 0 12px hsl(var(--primary))",
              }}
            />
          </div>

          {/* Era Nodes */}
          {ERAS.map((era) => {
            const percent = yearToPercent(era.year);
            const isActive = Math.abs(currentYear - era.year) < 50;

            return (
              <div
                key={era.year}
                className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 transition-all duration-200"
                style={{ left: `${percent}%` }}
              >
                {/* Node circle */}
                <div
                  className={`
                    w-4 h-4 rounded-full border-2 transition-all duration-200
                    ${isActive 
                      ? "bg-primary border-primary scale-150 shadow-brass" 
                      : "bg-background border-border hover:bg-primary/20"
                    }
                  `}
                  onClick={(e) => {
                    e.stopPropagation();
                    onYearChange(era.year);
                  }}
                  role="button"
                  aria-label={`Jump to ${era.label} era (${era.year})`}
                />

                {/* Era label */}
                <div
                  className={`
                    absolute top-6 left-1/2 -translate-x-1/2 whitespace-nowrap
                    text-xs font-serif transition-all duration-200
                    ${isActive ? "text-primary font-semibold" : "text-muted-foreground"}
                  `}
                >
                  {era.label}
                </div>
              </div>
            );
          })}

          {/* Current position marker */}
          <div
            className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 transition-all duration-200"
            style={{ left: `${currentPercent}%` }}
          >
            <div className="flex flex-col items-center">
              <Milestone className="w-6 h-6 text-accent drop-shadow-lg hologram-glow" />
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="text-center mt-3 text-xs text-muted-foreground font-serif italic">
          Drag to scrub through time • Click nodes to jump • Use ← → arrow keys
        </div>
      </div>
    </div>
  );
};
