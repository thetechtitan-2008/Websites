import { useState, memo, useCallback } from "react";
import { ChevronLeft, ChevronRight, BookmarkPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { useTheme } from "next-themes";

interface PageContent {
  title: string;
  year: number;
  content: string;
  illustration?: string;
}

interface PageFlipProps {
  pages: PageContent[];
  currentPage: number;
  onPageChange: (page: number) => void;
}

const PageFlipComponent = ({ pages, currentPage, onPageChange }: PageFlipProps) => {
  const [isFlipping, setIsFlipping] = useState(false);
  const [flipDirection, setFlipDirection] = useState<"left" | "right" | null>(null);
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const handleFlip = useCallback((direction: "left" | "right") => {
    if (isFlipping) return;

    const newPage = direction === "left" 
      ? Math.max(0, currentPage - 1)
      : Math.min(pages.length - 1, currentPage + 1);

    if (newPage === currentPage) return;

    setIsFlipping(true);
    setFlipDirection(direction);

    // Simulate page flip animation
    setTimeout(() => {
      onPageChange(newPage);
      setIsFlipping(false);
      setFlipDirection(null);
    }, 700); // Match --duration-page-flip
  }, [currentPage, pages.length, onPageChange]);

  const page = pages[currentPage];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1, delay: 0.6, ease: "easeOut" }}
      className="relative w-full max-w-4xl mx-auto perspective-lg px-2 md:px-4"
    >
      {/* Book Shadow */}
      <div className="absolute inset-0 rounded-lg shadow-lifted opacity-30 blur-xl" />

      {/* Open Book with Parchment Background */}
      <div 
        className="relative rounded-lg overflow-hidden preserve-3d"
        style={{
          background: isDark 
            ? 'linear-gradient(to bottom, #1a1f2e 0%, #242938 20%, #1e2330 40%, #242938 60%, #1a1f2e 80%, #151820 100%)'
            : `linear-gradient(to bottom, 
                #f4e8d0 0%, 
                #eddcb8 20%, 
                #f0e4cc 40%, 
                #eddcb8 60%, 
                #f4e8d0 80%, 
                #e8d5b5 100%
              )`,
          boxShadow: isDark 
            ? 'inset 0 0 80px rgba(176, 125, 59, 0.15), 0 10px 50px rgba(0, 0, 0, 0.6)'
            : 'inset 0 0 80px rgba(139, 90, 43, 0.15), 0 10px 50px rgba(0, 0, 0, 0.3)',
          border: isDark 
            ? '2px solid rgba(176, 125, 59, 0.4)'
            : '2px solid rgba(139, 90, 43, 0.3)'
        }}
      >
        {/* Aged Paper Texture Overlay */}
        <div 
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{
            backgroundImage: `
              repeating-linear-gradient(
                0deg,
                transparent,
                transparent 2px,
                rgba(139, 90, 43, 0.03) 2px,
                rgba(139, 90, 43, 0.03) 4px
              ),
              repeating-linear-gradient(
                90deg,
                transparent,
                transparent 2px,
                rgba(139, 90, 43, 0.03) 2px,
                rgba(139, 90, 43, 0.03) 4px
              )
            `
          }}
        />

        {/* Coffee Stains and Age Marks - Only in light mode */}
        {!isDark && (
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-12 right-24 w-20 h-20 rounded-full opacity-10" 
              style={{ background: 'radial-gradient(circle, rgba(101, 67, 33, 0.4) 0%, transparent 70%)' }} 
            />
            <div className="absolute bottom-32 left-16 w-24 h-24 rounded-full opacity-8" 
              style={{ background: 'radial-gradient(circle, rgba(101, 67, 33, 0.3) 0%, transparent 70%)' }} 
            />
            <div className="absolute top-1/3 left-1/4 w-16 h-16 rounded-full opacity-6" 
              style={{ background: 'radial-gradient(circle, rgba(101, 67, 33, 0.2) 0%, transparent 70%)' }} 
            />
          </div>
        )}

        {/* Left Page (Previous) - Hidden on mobile */}
        <div className={`hidden md:block absolute left-0 top-0 w-1/2 h-full border-r-2 p-8 md:p-12 ${
          isDark ? 'border-brass-shine/30' : 'border-amber-950/30'
        }`}>
          {currentPage > 0 && (
            <div className="opacity-40 text-sm font-handwriting">
              <p className={`italic ${isDark ? 'text-brass-shine/70' : 'text-amber-900/70'}`}>
                {pages[currentPage - 1].title}
              </p>
            </div>
          )}
        </div>

        {/* Right Page (Current) */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className={`
              relative w-full min-h-[500px] sm:min-h-[600px] md:min-h-[700px] p-6 sm:p-8 md:p-12
              ${isFlipping && flipDirection === "right" ? "page-flip" : ""}
            `}
            style={{
              transformOrigin: flipDirection === "right" ? "left center" : "right center",
              transform: isFlipping && flipDirection === "right" ? "rotateY(-180deg)" : "none",
            }}
          >
            {/* Page number */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className={`absolute top-4 right-4 text-xs font-handwriting ${
                isDark ? 'text-brass-shine/60' : 'text-amber-900/60'
              }`}
            >
              Page {currentPage + 1} of {pages.length}
            </motion.div>

            {/* Bookmark */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 left-4 text-primary hover:text-primary/80 hover:bg-amber-900/10"
              aria-label="Bookmark this page"
            >
              <BookmarkPlus className="w-5 h-5" />
            </Button>

            {/* Content */}
            <div className="space-y-6 mt-12">
              {/* Year badge */}
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2, duration: 0.4 }}
                className={`inline-block px-4 py-2 border-2 rounded-md backdrop-blur-sm ${
                  isDark ? 'bg-brass-shine/20 border-brass-shine/40' : 'bg-amber-900/20 border-amber-900/40'
                }`}
              >
                <span className={`font-handwriting text-lg font-bold ${
                  isDark ? 'text-brass-shine' : 'text-amber-950'
                }`}>
                  Year {page.year > 0 ? page.year : `${Math.abs(page.year)} BCE`}
                </span>
              </motion.div>

              {/* Title with hand-drawn underline */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.5 }}
                className="relative"
              >
                <h2 className={`text-3xl md:text-4xl font-script mb-2 font-bold ${
                  isDark ? 'text-brass-shine' : 'text-amber-950'
                }`}>
                  {page.title}
                </h2>
                <svg
                  className="absolute -bottom-2 left-0 w-48 h-2"
                  viewBox="0 0 200 8"
                  preserveAspectRatio="none"
                >
                  <path
                    d="M0,4 Q50,1 100,4 T200,4"
                    stroke={isDark ? 'rgba(176, 125, 59, 0.6)' : 'rgba(101, 67, 33, 0.6)'}
                    strokeWidth="2"
                    fill="none"
                    strokeLinecap="round"
                    className="ink-stroke"
                  />
                </svg>
              </motion.div>

              {/* Illustration */}
              {page.illustration && (
                <div className="my-6 rounded-lg overflow-hidden border-2 border-amber-900/40 shadow-paper">
                  <img
                    src={page.illustration}
                    alt={`Illustration for ${page.title}`}
                    className="w-full h-64 object-cover sepia"
                    loading="lazy"
                    decoding="async"
                  />
                </div>
              )}

              {/* Entry content - Handwritten style */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5, duration: 0.8 }}
                className="prose prose-lg max-w-none"
              >
                <p className={`font-handwriting text-lg leading-relaxed whitespace-pre-line tracking-wide ${
                  isDark ? 'text-foreground' : 'text-amber-950'
                }`}
                  style={{
                    textShadow: isDark ? '0 1px 2px rgba(0, 0, 0, 0.5)' : '0 1px 1px rgba(101, 67, 33, 0.1)',
                    letterSpacing: '0.02em'
                  }}
                >
                  {page.content}
                </p>
              </motion.div>

              {/* Decorative flourish */}
              <motion.div 
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7, duration: 0.5 }}
                className="flex items-center justify-center my-8"
              >
                <svg width="120" height="30" viewBox="0 0 120 30">
                  <path
                    d="M10,15 Q30,5 60,15 T110,15"
                    stroke={isDark ? 'rgba(176, 125, 59, 0.4)' : 'rgba(101, 67, 33, 0.4)'}
                    strokeWidth="1.5"
                    fill="none"
                  />
                  <circle cx="60" cy="15" r="3" fill={isDark ? 'rgba(176, 125, 59, 0.4)' : 'rgba(101, 67, 33, 0.4)'} />
                  <circle cx="30" cy="12" r="2" fill={isDark ? 'rgba(176, 125, 59, 0.3)' : 'rgba(101, 67, 33, 0.3)'} />
                  <circle cx="90" cy="12" r="2" fill={isDark ? 'rgba(176, 125, 59, 0.3)' : 'rgba(101, 67, 33, 0.3)'} />
                </svg>
              </motion.div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Controls - Responsive size */}
      <div className="absolute top-1/2 -translate-y-1/2 -left-4 -right-4 sm:-left-6 sm:-right-6 md:-left-12 md:-right-12 flex justify-between pointer-events-none z-20">
        <motion.div
          whileHover={{ scale: 1.1, x: -4 }}
          whileTap={{ scale: 0.95 }}
          animate={{ opacity: currentPage === 0 ? 0.3 : 1 }}
        >
          <Button
            variant="default"
            size="icon"
            className="pointer-events-auto w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 rounded-full bg-primary/90 hover:bg-primary backdrop-blur-sm shadow-lifted hover:shadow-2xl transition-all border-2 border-brass-shine/50"
            onClick={() => handleFlip("left")}
            disabled={currentPage === 0 || isFlipping}
            aria-label="Previous page"
          >
            <ChevronLeft className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-primary-foreground" />
          </Button>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.1, x: 4 }}
          whileTap={{ scale: 0.95 }}
          animate={{ opacity: currentPage === pages.length - 1 ? 0.3 : 1 }}
        >
          <Button
            variant="default"
            size="icon"
            className="pointer-events-auto w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 rounded-full bg-primary/90 hover:bg-primary backdrop-blur-sm shadow-lifted hover:shadow-2xl transition-all border-2 border-brass-shine/50"
            onClick={() => handleFlip("right")}
            disabled={currentPage === pages.length - 1 || isFlipping}
            aria-label="Next page"
          >
            <ChevronRight className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-primary-foreground" />
          </Button>
        </motion.div>
      </div>

      {/* Keyboard hint */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
        className={`text-center mt-6 text-sm font-handwriting italic ${
          isDark ? 'text-brass-shine/70' : 'text-amber-900/70'
        }`}
      >
        Use ← → arrow keys to flip pages
      </motion.div>
    </motion.div>
  );
};

export const PageFlip = memo(PageFlipComponent);
